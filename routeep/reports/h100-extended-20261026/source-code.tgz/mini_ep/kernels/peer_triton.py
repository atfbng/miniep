"""Peer copies, device signals, GPU address planning and TMA SwiGLU Up.

All pointers are supplied by distributed.peer.PeerSwiGLU. Payloads are BF16;
counts/offsets/branch identities are int64, readiness and epoch flags are int32.
Top-K is expanded only by sorted branch identities in _send; inputs remain
original [N,H]. Receivers are compact Expert-major, then EP-source-major.
These kernels own no allocations, groups or host synchronization.
"""
import triton
import triton.language as tl


@triton.jit
def _wait(ptr, threshold):
    """Acquire one system-scope int32 completion counter on this GPU."""
    while tl.atomic_add(ptr, 0, sem="acquire", scope="sys") < threshold:
        tl.inline_asm_elementwise("nanosleep.u32 128; mov.u32 $0, 0;", "=r", [], dtype=tl.int32, is_pure=False, pack=1)


@triton.jit
def _signal(Ptrs, epoch, P: tl.constexpr, RANK: tl.constexpr, FINISH: tl.constexpr):
    """uint64 Ptrs[P] -> publish/wait epoch in each peer's int32 flags[2P]."""
    for peer in range(P):
        ptr = tl.load(Ptrs + peer).to(tl.pointer_type(tl.int32))
        tl.atomic_xchg(ptr + FINISH * P + RANK, epoch, sem="release", scope="sys")
    own = tl.load(Ptrs + RANK).to(tl.pointer_type(tl.int32))
    for peer in range(P):
        _wait(own + FINISH * P + peer, epoch)


@triton.jit
def _layout(Counts, SendStarts, Targets, SourceRows, TileStarts, Offsets,
            E: tl.constexpr, P: tl.constexpr, L: tl.constexpr,
            RANK: tl.constexpr, BM: tl.constexpr, BE: tl.constexpr, BP: tl.constexpr):
    """int64 Counts[P,E] -> int64 source/target offsets[E], local offsets[L+1].

    All are contiguous device tensors. Starts addresses Expert-sorted source
    branches; Targets includes the earlier EP sources within each target Expert;
    SourceRows is that source prefix, TileStarts is the target's Expert tile base.
    """
    e = tl.arange(0, BE)
    source = tl.arange(0, BP)
    counts = tl.load(Counts + source[:, None] * E + e[None, :],
                     (source[:, None] < P) & (e[None, :] < E), 0)
    total = tl.sum(counts, 0)
    # Reset cumulative expert counts at each owner rank boundary.
    totals = tl.reshape(total, (P, BE // P))
    within = tl.cumsum(totals, 1) - totals
    tiles = tl.cdiv(totals, BM)
    tile_starts = tl.cumsum(tiles, 1) - tiles
    local = tl.load(Counts + RANK * E + e, e < E, 0)
    prior_sources = tl.sum(tl.where(source[:, None] < RANK, counts, 0), 0)
    tl.store(SendStarts + e, tl.cumsum(local) - local, e < E)
    tl.store(Targets + e, tl.reshape(within, (BE,)) + prior_sources, e < E)
    tl.store(SourceRows + e, prior_sources, e < E)
    tl.store(TileStarts + e, tl.reshape(tile_starts, (BE,)), e < E)
    begin = RANK * L
    local_mask = (e >= begin) & (e < begin + L)
    tl.store(Offsets + e - begin, tl.reshape(within, (BE,)), local_mask)
    tl.store(Offsets + L, tl.sum(tl.where(local_mask, total, 0), 0))


@triton.jit
def _plan(Offsets, Experts, Rows, Expected, L: tl.constexpr, BM: tl.constexpr,
          CAP: tl.constexpr, BL: tl.constexpr, BT: tl.constexpr, HC: tl.constexpr):
    """int64 Offsets[L+1] -> Expert/relative-row/expected-copy maps[CAP].

    CAP bounds sum ceil(expert_rows/BM); invalid tail Experts=-1. Each valid
    tile expects valid_rows*HC releases. HC=ceil(H/copy_columns).
    """
    e = tl.arange(0, BL)
    first = tl.load(Offsets + e, e < L, 0)
    end = tl.load(Offsets + e + 1, e < L, 0)
    tile_ends = tl.cumsum(tl.cdiv(end - first, BM))
    tile = tl.arange(0, BT)
    lo = tl.full((BT,), 0, tl.int32)
    hi = tl.full((BT,), L, tl.int32)
    for _ in range((L + 1).bit_length()):
        mid = (lo + hi) // 2
        value = tl.gather(tile_ends, tl.minimum(mid, BL - 1), 0)
        smaller = (mid < L) & (value <= tile)
        lo = tl.where(smaller, mid + 1, lo)
        hi = tl.where(smaller, hi, mid)
    expert = lo
    previous = tl.gather(tile_ends, tl.maximum(expert - 1, 0), 0)
    relative = (tile - tl.where(expert == 0, 0, previous)) * BM
    count = tl.gather(end - first, tl.minimum(expert, BL - 1), 0)
    tl.store(Expected + tile, tl.minimum(BM, count - relative) * HC, (tile < CAP) & (expert < L))
    tl.store(Experts + tile, tl.where(expert < L, expert, -1), tile < CAP)
    tl.store(Rows + tile, relative, tile < CAP)


@triton.jit
def _send(X, Ids, Weights, Order, Starts, Targets, SourceRows, TileStarts,
          DataPtrs, MetaPtrs, WeightPtrs, ReadyPtrs,
          B, H: tl.constexpr, K: tl.constexpr, L: tl.constexpr,
          RANK: tl.constexpr, BM: tl.constexpr, BH: tl.constexpr):
    """Original BF16 X[N,H], flattened IDs/FP32 weights[B], sorted Order[B].

    B=N*K. uint64 Ptrs[P] address compact Expert-major receive buffers, int64
    (source,branch) metadata[R,2], FP32 weights[R], int32 readiness[tile_capacity].
    Every source writes a disjoint row range; no floating-point atomics occur.
    """
    row = tl.program_id(0) * 16 + tl.arange(0, 16)
    col = tl.program_id(1) * BH + tl.arange(0, BH)
    valid = row < B
    branch = tl.load(Order + row, valid, 0)
    expert = tl.load(Ids + branch, valid, 0)
    owner = expert // L
    within = row - tl.load(Starts + expert)
    destination = tl.load(Targets + expert) + within
    data = tl.load(DataPtrs + owner).to(tl.pointer_type(X.dtype.element_ty))
    meta = tl.load(MetaPtrs + owner).to(tl.pointer_type(tl.int64))
    weight_ptr = tl.load(WeightPtrs + owner).to(tl.pointer_type(tl.float32))
    value = tl.load(X + (branch[:, None] // K) * H + col[None, :],
                    valid[:, None] & (col[None, :] < H), 0)
    tl.store(data[:, None] + destination[:, None] * H + col[None, :], value,
             valid[:, None] & (col[None, :] < H))
    if tl.program_id(1) == 0:
        tl.store(meta + destination * 2, RANK, valid)
        tl.store(meta + destination * 2 + 1, branch, valid)
        tl.store(weight_ptr + destination, tl.load(Weights + branch, valid, 0), valid)
    # acq_rel chains all copy CTAs' releases; Up acquires the tile threshold.
    tl.debug_barrier()
    ready = tl.load(ReadyPtrs + owner).to(tl.pointer_type(tl.int32))
    expert_row = tl.load(SourceRows + expert) + within
    tile = tl.load(TileStarts + expert) + expert_row // BM
    tl.atomic_add(ready + tile, 1, mask=valid, sem="acq_rel", scope="sys")


@triton.jit
def _up(InputDesc, WeightDesc, Activation, Offsets, Experts, Rows, Ready, Expected,
        F: tl.constexpr, H: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr,
        BK: tl.constexpr):
    """BF16 TMA descriptors [capacity,H]/[L*2F,H] -> BF16 Activation[capacity,F].

    Expert offsets and tile maps are device int64. Only valid expert rows are
    written; Down uses the same plan and never consumes the uninitialized tail.
    """
    tile = tl.program_id(0)
    expert = tl.load(Experts + tile).to(tl.int32)
    if expert < 0:
        return
    first = tl.load(Offsets + expert)
    end = tl.load(Offsets + expert + 1)
    start = (first + tl.load(Rows + tile)).to(tl.int32)
    rows = start + tl.arange(0, BM)
    # Up waits only for this Expert tile's copy chunks, including all sources.
    _wait(Ready + tile, tl.load(Expected + tile))
    # Peer copies use the generic proxy; TMA loads use the async proxy. The
    # system acquire orders producers, then this fence makes their writes
    # visible to the descriptor's async loads before they are issued.
    tl.inline_asm_elementwise(
        "fence.proxy.async.global; mov.u32 $0, 0;", "=r", [],
        dtype=tl.int32, is_pure=False, pack=1,
    )
    cols = tl.program_id(1) * BN + tl.arange(0, BN)
    gate_acc = tl.zeros((BM, BN), tl.float32)
    up_acc = tl.zeros((BM, BN), tl.float32)
    for step in range(tl.cdiv(H, BK)):
        x = InputDesc.load([start, step * BK])
        gate = WeightDesc.load([expert * (2 * F) + tl.program_id(1) * BN, step * BK]).T
        up = WeightDesc.load([expert * (2 * F) + F + tl.program_id(1) * BN, step * BK]).T
        gate_acc = tl.dot(x, gate, gate_acc)
        up_acc = tl.dot(x, up, up_acc)
    gate_value = gate_acc.to(Activation.dtype.element_ty).to(tl.float32)
    up_value = up_acc.to(Activation.dtype.element_ty).to(tl.float32)
    silu = (gate_value / (1.0 + tl.exp(-gate_value))).to(Activation.dtype.element_ty).to(tl.float32)
    tl.store(Activation + rows[:, None] * F + cols[None, :], silu * up_value,
             (rows[:, None] < end) & (cols[None, :] < F))


@triton.jit
def _push(Outputs, Meta, Offsets, ReturnedPtrs, H: tl.constexpr,
          L: tl.constexpr, BH: tl.constexpr):
    """Weighted BF16 Outputs[R,H] -> peer returned[original_branch,H].

    int64 Meta[R,2] supplies EP source rank and token-major/slot-minor branch.
    Offsets[L] is the valid receive-row count; capacity-tail rows are skipped.
    """
    row = tl.program_id(0) * 16 + tl.arange(0, 16)
    col = tl.program_id(1) * BH + tl.arange(0, BH)
    valid = row < tl.load(Offsets + L)
    source = tl.load(Meta + row * 2, valid, 0)
    branch = tl.load(Meta + row * 2 + 1, valid, 0)
    ptr = tl.load(ReturnedPtrs + source).to(tl.pointer_type(Outputs.dtype.element_ty))
    value = tl.load(Outputs + row[:, None] * H + col[None, :],
                    valid[:, None] & (col[None, :] < H), 0)
    tl.store(ptr[:, None] + branch[:, None] * H + col[None, :], value,
             valid[:, None] & (col[None, :] < H))


