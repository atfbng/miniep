"""Experimental single-node, dynamic-route Peer Memory SwiGLU EP.

Adapted from course 12's separated execution protocol; this is a local
implementation, with BF16 SwiGLU, arbitrary Top-K and dynamic device metadata.
No model, process group or CUDA allocation is created at import time.
"""
from __future__ import annotations

import torch
import torch.distributed as dist
import torch.distributed._symmetric_memory as symm
import triton
from triton.tools.tensor_descriptor import TensorDescriptor

from mini_ep.distributed.topology import ExpertParallelTopology
from mini_ep.model.contracts import validate_inputs
from mini_ep.kernels.grouped_gemm.plan import GroupedGemmPlan
from mini_ep.kernels.grouped_gemm.triton_impl import grouped_gemm
from mini_ep.kernels.combine_triton import combine_triton
from mini_ep.profiler.stages import Stages
from mini_ep.kernels.peer_triton import _layout, _plan, _send, _signal, _up, _push


class PeerSwiGLU:
    """Reusable workspace for one single-node NCCL EP group, one CUDA stream.

    Tokens [N,H] and local weights [L,2F,H]/[L,H,F] are contiguous CUDA BF16;
    unexpanded IDs [N,K] int64, weights [N,K] FP32. Uniform placement E=P*L.
    Counts [P,E] are gathered (integer metadata only). Inputs go directly into
    compact expert-major rows, source-major within each expert. Return metadata
    [R,2] stores (EP source rank, original token-major branch number).

    The input capacity is P*max(source_rows)*K (rounded to BM), a safe bound for arbitrarily skewed
    routes; returned capacity is max(source_rows)*K. All peers allocate the same
    shapes. Source sizes may vary each call within the declared bound. Calls on
    all ranks must use identical options and order, including zero-token ranks.
    All ranks are local; global rank can differ from EP rank. local rank selects
    the CUDA device, and peer pointer arrays are ordered by EP group rank.

    Start release/acquire protects the previous combine and resets readiness.
    Copy publishes tile/chunk readiness, Up acquires it per BM tile; Down and push
    follow on the same stream. Finish release/acquire protects returned reads.
    There are no CPU Work handles: peer signals establish GPU completion, not a
    Python return. Output is newly allocated by combine. Synchronize this stream
    before destroying the workspace/group. Cross-stream calls are rejected.
    """
    def __init__(self, group: dist.ProcessGroup, hidden: int, local_experts: int, top_k: int,
                 source_rows: list[int], device: torch.device) -> None:
        self.group = group
        self.p, self.rank = dist.get_world_size(group), dist.get_rank(group)
        self.topology = ExpertParallelTopology(local_experts * self.p, self.p, self.rank)
        self.e, self.l, self.h, self.k = local_experts * self.p, local_experts, hidden, top_k
        if len(source_rows) != self.p or any(n < 0 for n in source_rows):
            raise ValueError(f"source_rows={source_rows} must have {self.p} nonnegative entries")
        if min(hidden, local_experts, top_k) < 1 or top_k > self.e:
            raise ValueError(f"require H,L,K>0 and K<=E, got {hidden},{local_experts},{top_k}")
        if self.e & (self.e - 1):
            raise ValueError(f"experimental peer layout requires power-of-two E, got {self.e}")
        if not torch.cuda.is_available() or device.type != "cuda":
            raise ValueError("PeerSwiGLU requires CUDA")
        if torch.cuda.get_device_capability(device)[0] < 9 or hidden % 8:
            raise ValueError("TMA peer path requires SM>=90 and H divisible by 8")
        self.device, self.stream = device, torch.cuda.current_stream(device).cuda_stream
        self.source_limit = max(1, max(source_rows))
        self.capacity = triton.cdiv(self.source_limit * self.p * top_k, 128) * 128
        self.return_capacity = max(1, self.source_limit * top_k)
        self.epoch = 0
        # Keep allocations AND mapping handles alive until all submitted work drains.
        specs = [((self.capacity, hidden), torch.bfloat16),
                 ((self.capacity, 2), torch.int64), ((self.capacity,), torch.float32),
                 ((self.capacity,), torch.int32),
                 ((self.return_capacity, hidden), torch.bfloat16),
                 ((2 * self.p,), torch.int32)]
        self.buffers = [symm.empty(*shape, dtype=dtype, device=device) for shape, dtype in specs]
        self.data, self.meta, self.weights, self.ready, self.returned, self.flags = self.buffers
        self.ready.zero_()
        self.flags.zero_()
        self.handles = [symm.rendezvous(t, group) for t in self.buffers]
        self.ptrs = [torch.tensor(h.buffer_ptrs, dtype=torch.uint64, device=device) for h in self.handles]
        self.counts = torch.empty((self.p, self.e), dtype=torch.int64, device=device)
        self.starts = torch.empty(self.e, dtype=torch.int64, device=device)
        self.targets = torch.empty_like(self.starts)
        self.source_prefixes = torch.empty_like(self.starts)
        self.tile_starts = torch.empty_like(self.starts)
        self.offsets = torch.empty(self.l + 1, dtype=torch.int64, device=device)
        tiles = triton.cdiv(self.capacity, 128) + self.l - 1
        self.experts = torch.empty(tiles, dtype=torch.int64, device=device)
        self.rows = torch.empty_like(self.experts)
        self.expected = torch.empty_like(self.experts)
        self.plan = GroupedGemmPlan(self.offsets, self.experts, self.rows, 128, self.capacity)
        # Construction is an explicit preparation boundary, outside steady state.
        torch.cuda.synchronize(device)
        dist.barrier(group)

    def forward(
        self, tokens: torch.Tensor, ids: torch.Tensor, weights: torch.Tensor,
        w13: torch.Tensor, w2: torch.Tensor, *, stages: Stages | None = None,
        validate: bool = True,
    ) -> tuple[torch.Tensor, dict]:
        """Original [N,H] -> original BF16 [N,H]; see class layout contract."""
        if validate:
            validate_inputs(tokens, ids, weights, w13, w2, self.topology)
        if (tokens.dtype != torch.bfloat16 or tokens.device != self.device
            or ids.dtype != torch.int64 or ids.shape[1] != self.k
            or tokens.shape[1] != self.h or w13.shape[0] != self.l
            or tokens.shape[0] > self.source_limit
            or weights.dtype != torch.float32 or weights.shape != ids.shape
            or w13.dtype != tokens.dtype or w2.dtype != tokens.dtype
            or any(t.device != tokens.device for t in (ids, weights, w13, w2))
            or not all(t.is_contiguous() for t in (tokens, ids, weights, w13, w2))):
            raise ValueError("peer expects contiguous BF16 tokens/weights, int64 IDs, FP32 routing weights within prepared H/L/K/N capacity")
        if w2.shape[2] % 128:
            raise ValueError(f"TMA fused Up requires F divisible by 128, got {w2.shape[2]}")
        if torch.cuda.current_stream(self.device).cuda_stream != self.stream:
            raise RuntimeError("peer workspace calls must use their construction CUDA stream")
        if self.epoch >= 2**31 - 1:
            raise RuntimeError("peer epoch exhausted; drain and recreate workspace")
        stages = stages or Stages()
        self.epoch += 1
        with stages.stage("DISPATCH"):
            flat = ids.view(-1)
            order = torch.argsort(flat, stable=True)
            counts = torch.bincount(flat, minlength=self.e)
            # Metadata AllGather is not a Token/TP AllGather. Payloads use peer writes.
            dist.all_gather_into_tensor(self.counts.view(-1), counts, group=self.group)
            _layout[(1,)](self.counts, self.starts, self.targets, self.source_prefixes, self.tile_starts, self.offsets,
                self.e, self.p, self.l, self.rank, 128, self.e, triton.next_power_of_2(self.p))
            _plan[(1,)](self.offsets, self.experts, self.rows, self.expected, self.l, 128,
                self.experts.numel(), triton.next_power_of_2(self.l),
                triton.next_power_of_2(self.experts.numel()), triton.cdiv(self.h, 256))
            self.ready.zero_()
            _signal[(1,)](self.ptrs[5], self.epoch, self.p, self.rank, False)
        with stages.stage("A2A_FORWARD"):
            if flat.numel():
                _send[(triton.cdiv(flat.numel(), 16), triton.cdiv(self.h, 256))](tokens, flat, weights, order,
                    self.starts, self.targets, self.source_prefixes, self.tile_starts, *self.ptrs[:4],
                    flat.numel(), self.h, self.k, self.l, self.rank, 128, 256)
        with stages.stage("EXPERT"):
            f = w2.shape[2]
            activated = torch.empty((self.capacity, f), dtype=tokens.dtype, device=self.device)
            input_desc = TensorDescriptor(self.data, [self.capacity, self.h], [self.h, 1], [128, 64])
            weight_desc = TensorDescriptor(w13, [self.l * 2 * f, self.h], [self.h, 1], [128, 64])
            _up[(self.experts.numel(), triton.cdiv(f, 128))](input_desc, weight_desc, activated,
                self.offsets, self.experts, self.rows, self.ready, self.expected, f, self.h, 128, 128, 64,
                num_warps=8, num_stages=3, enable_fp_fusion=False)
            output = grouped_gemm(activated, w2, self.plan, output_dtype=tokens.dtype, row_weights=self.weights)
        with stages.stage("A2A_RETURN"):
            _push[(triton.cdiv(self.capacity, 16), triton.cdiv(self.h, 256))](output, self.meta, self.offsets,
                self.ptrs[4], self.h, self.l, 256)
            _signal[(1,)](self.ptrs[5], self.epoch, self.p, self.rank, True)
        with stages.stage("COMBINE"):
            restore = torch.arange(flat.numel(), dtype=torch.int64, device=self.device)
            result = combine_triton(self.returned, restore, ids, self.topology, model_dtype=tokens.dtype)
        return result, dict(transport="peer", layout="compact-expert-major", branches=flat.numel(),
            source_tokens=tokens.shape[0], input_capacity=self.capacity, epoch=self.epoch,
            return_dtype=str(tokens.dtype), preweighted=True, expert_backend="peer_tma_swiglu",
            fixed_a2a=False, ep_size=self.p)


_WORKSPACES: dict[tuple, PeerSwiGLU] = {}


def peer_forward(
    tokens: torch.Tensor, ids: torch.Tensor, weights: torch.Tensor,
    w13: torch.Tensor, w2: torch.Tensor, group: dist.ProcessGroup, *,
    source_rows: list[int], stages: Stages | None = None, validate: bool = True,
) -> tuple[torch.Tensor, dict]:
    """Dynamic-route entry, sharing capacity-bucket workspaces across model layers.

    Host source_rows must match actual EP-rank token sizes and be identical on
    every rank; vLLM supplies these sizes without GPU reads. Growth/rendezvous
    is preparation cost inside the first affected model step, never hidden from
    end-to-end timing. Caches are process-local and inference-only/non-reentrant.
    """
    p = dist.get_world_size(group)
    rank = dist.get_rank(group)
    if (len(source_rows) != p or any(n < 0 for n in source_rows)
        or source_rows[rank] != tokens.shape[0]):
        raise ValueError(f"source_rows={source_rows} must match EP={p} and local N={tokens.shape[0]}")
    limit = triton.next_power_of_2(max(1, max(source_rows)))
    # Reusing the largest prefill workspace for one-token decode would launch
    # thousands of empty tile/copy CTAs. Buckets bound the work by current N;
    # across all power-of-two buckets their memory is below twice the largest.
    key = (group, tokens.device, tokens.shape[1], w13.shape[0], ids.shape[1], limit)
    workspace = _WORKSPACES.get(key)
    if workspace is None:
        replacement = PeerSwiGLU(group, tokens.shape[1], w13.shape[0], ids.shape[1],
                                [limit] * p, tokens.device)
        _WORKSPACES[key] = replacement
        workspace = replacement
    return workspace.forward(tokens, ids, weights, w13, w2, stages=stages, validate=validate)


def clear_peer_workspaces() -> None:
    """Drain and release mappings before destroying their process groups."""
    for workspace in _WORKSPACES.values():
        torch.cuda.synchronize(workspace.device)
    _WORKSPACES.clear()
