"""Two-rank Qwen3.5 BF16 validation against native NCCL, plus PyTorch MoE.

Run independent native then miniep engines with torchrun --nproc-per-node=2.
This deliberately does not label the native NCCL control as DeepEP.
"""

import argparse
from datetime import timedelta
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mini_ep.integration.config import configure, engine_options
from validation.alignment_cases import build_cases


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--model", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--backend", choices=["native", "miniep"], required=True)
    p.add_argument("--reference")
    p.add_argument("--smoke", action="store_true")
    a = p.parse_args()
    if int(os.environ.get("WORLD_SIZE", "0")) != 2 or (a.backend == "miniep" and not a.reference):
        p.error("requires two torchrun ranks and miniep requires --reference")
    configure(a.backend)
    os.environ.update(VLLM_ENABLE_V1_MULTIPROCESSING="0", VLLM_PLUGINS="", NCCL_NVLS_ENABLE="0")
    import torch
    import torch.distributed as dist
    torch.cuda.set_device(int(os.environ["LOCAL_RANK"]))
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    dist.init_process_group("nccl", timeout=timedelta(seconds=300))
    rank = dist.get_rank()
    root = Path(a.output).resolve() / f"rank{rank}"
    root.mkdir(parents=True, exist_ok=False)
    os.environ["ROUTEEP_CONSUMER_OUTPUT"] = str(root)
    options = engine_options(a.model, dp_size=2, tp_size=1, external=True, all2all_backend="allgather_reducescatter")
    options.update(max_model_len=2304, max_num_batched_tokens=8192, max_num_seqs=32,
                   gpu_memory_utilization=.94, kv_cache_memory_bytes=512 * 1024**2,
                   enable_dbo=False, enable_eplb=False, quantization=None,
                   safetensors_load_strategy="prefetch", safetensors_prefetch_num_threads=2,
                   distributed_timeout_seconds=300, cpu_distributed_timeout_seconds=300)
    (root / "environment.json").write_text(json.dumps(dict(options=options, rank=rank, backend=a.backend,
        versions={n:importlib.metadata.version(n) for n in ("torch", "vllm", "triton", "transformers")}), indent=2))
    from mini_ep.integration.plugin import prepare_runtime, register
    prepare_runtime()
    register()
    from validation import consumer_probe
    consumer_probe.install(a.backend)
    from vllm import LLM, SamplingParams
    llm = LLM(**options)
    llm.collective_rpc(consumer_probe.verify_model, timeout=300)
    from vllm.distributed import get_dp_group, get_ep_group, get_tp_group
    assert (get_tp_group().world_size, get_dp_group().world_size, get_ep_group().world_size) == (1, 2, 2)
    dp = get_dp_group().rank_in_group

    def execute(case, seed=13):
        lengths = case.get("request_steps", [case["steps"]] * len(case["prompts"]))
        sampling = [SamplingParams(temperature=0, seed=seed, max_tokens=n, ignore_eos=True) for n in lengths]
        if case["prompts"]:
            llm.enqueue(case["prompts"], sampling, use_tqdm=False)
        outputs = llm.wait_for_completion(use_tqdm=False)
        if len(outputs) != len(case["prompts"]):
            raise RuntimeError("missing accuracy requests")
        records = []
        for prompt, length, result in zip(case["prompts"], lengths, outputs, strict=True):
            if result.prompt_token_ids != prompt["prompt_token_ids"] or len(result.outputs[0].token_ids) != length:
                raise RuntimeError("accuracy request identity/length mismatch")
            records.append(list(result.outputs[0].token_ids))
        return records

    tokenizer = llm.get_tokenizer()
    # Balanced short/long, different inputs on the two DP ranks, 512 full-vocab
    # logit rows total. Force only AFTER recording actual candidate logits.
    teacher = build_cases(tokenizer, "corpus", dp, "rotated", 4, 64 if not a.smoke else 4)[-1]
    baseline = (Path(a.reference) / f"rank{rank}" / "baseline_logits") if a.reference else (root / "baseline_logits")
    consumer_probe.CONTROL = dict(step=0, baseline=str(baseline))
    forced_tokens = execute(teacher)
    consumer_probe.CONTROL = None
    consumer_probe.flush(root)
    (root / "teacher-tokens.json").write_text(json.dumps(forced_tokens))
    manifests, outputs = [], []
    suites = [("corpus", "same", 13, 64), ("corpus", "rotated", 13, 64),
              ("boundaries", "rotated", 13, 64), ("long", "rotated", 13, 256),
              ("corpus", "rotated", 13, 64), ("corpus", "rotated", 13, 64),
              ("corpus", "rotated", 37, 64), ("corpus", "rotated", 123, 64),
              ("performance", "rotated", 13, 128)]
    if a.smoke:
        suites = [("boundaries", "rotated", 13, 4)]
    for index, (suite, corpus, seed, steps) in enumerate(suites):
        cases = build_cases(tokenizer, suite, dp, corpus, 32, steps)
        if a.smoke:
            cases = cases[:1]
        for case in cases:
            key = f"s{index}-{case['name']}"
            manifests.append(dict(key=key, suite=suite, corpus=corpus, seed=seed, **case))
            tokens = execute(case, seed)
            outputs.append(dict(key=key, token_ids=tokens))
            (root / "manifest.json").write_text(json.dumps(manifests))
            (root / "outputs.json").write_text(json.dumps(outputs))
            print(f"ACCURACY rank={rank} backend={a.backend} key={key} requests={len(tokens)} positions={sum(map(len,tokens))}", flush=True)
    if a.reference:
        previous = Path(a.reference) / f"rank{rank}"
        if json.loads((previous / "manifest.json").read_text()) != manifests:
            raise RuntimeError("native/candidate input manifests differ")
        native = json.loads((previous / "outputs.json").read_text())
        compared = matched = sequences = exact_sequences = 0
        first = None
        for left, right in zip(native, outputs, strict=True):
            for i, (x, y) in enumerate(zip(left["token_ids"], right["token_ids"], strict=True)):
                sequences += 1
                exact_sequences += x == y
                if len(x) != len(y):
                    raise RuntimeError("native/candidate generation lengths differ")
                compared += len(x)
                matched += sum(u == v for u, v in zip(x, y, strict=True))
                if x != y and first is None:
                    pos = next(j for j,(u,v) in enumerate(zip(x,y)) if u != v)
                    first = dict(key=left["key"], request=i, position=pos, native=x[pos], miniep=y[pos])
        summary = dict(request_sequences=sequences, exact_sequences=exact_sequences,
                       generation_positions=compared, matching_positions=matched,
                       first_difference=first, all_tokens_exact=compared == matched)
        (root / "comparison.json").write_text(json.dumps(summary, indent=2))
    (root / "completed.json").write_text(json.dumps(dict(cases=len(outputs), requests=sum(len(x["token_ids"]) for x in outputs))))
    del llm
    gc.collect()
    from vllm.distributed import destroy_model_parallel, destroy_distributed_environment
    destroy_model_parallel()
    destroy_distributed_environment()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(1)
