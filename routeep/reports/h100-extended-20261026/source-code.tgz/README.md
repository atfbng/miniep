<div align="center">

# RouteEP

**接入 vLLM 的 MoE Expert Parallel 推理后端**

自研 Token 路由与 NCCL All-to-All 通信 · 在 4 × H100 上运行 Qwen3 / Qwen3.5 推理服务 · 端到端速度接近 DeepEP

</div>

---

## 亮点

| Decode 速度 | Prefill 速度 | 正确性 |
|:---:|:---:|:---:|
| **98.1%–98.8%** | **77.3%–88.8%** | **64,164** 个生成位置 |
| 相对 DeepEP HT（Qwen3.5） | 相对 DeepEP HT（Qwen3.5） | 每个模型的生成 Token 都与 DeepEP HT 一致 |

- **真实项目**：作为 vLLM 插件运行，覆盖整模型推理和 OpenAI 兼容服务，不是单独的算子演示。
- **完整 EP 链路**：路由、跨卡分发、Expert 计算、结果返回、加权合并全部自研实现，每一步都有 PyTorch Reference。
- **测量方法可复现**：与 DeepEP HT 在同一台机器上交替测量，原始报告保存在 `reports/`。

## 工作原理

vLLM 负责服务、调度、KV Cache 和 Attention；RouteEP 接管 MoE 层。每个 MoE 层的数据流如下：

```text
Router (Top-K)  →  Dispatch  →  All-to-All  →  Expert MLP  →  All-to-All  →  Combine
 选出 Expert       按目标 Rank     NCCL 发送到    本地 Grouped      NCCL 送回     按路由权重
                  打包 Token      Expert 所在卡   GEMM / SwiGLU    原 Rank       加权合并
```

1. **Router**：每个 Token 选出 Top-K 个 Expert 及对应权重。
2. **Dispatch**：按 Expert 所在的 Rank，把 Token 重排成连续的发送缓冲区。
3. **All-to-All 分发**：NCCL variable-split All-to-All 把 Token 送到持有对应 Expert 的 GPU。
4. **Expert 计算**：每张卡用 Grouped GEMM / SwiGLU 计算本地 Expert，Qwen3.5 还会计算 Shared Expert。
5. **All-to-All 返回**：计算结果原路送回 Token 所在的 Rank。
6. **Combine**：恢复原始 Token 顺序，按路由权重合并 Top-K 结果。

![vLLM 与 RouteEP 后端、四张 H100 的组件结构](assets/architecture.png)

四张 H100 的拓扑：Attention TP=2、DP=2，MoE EP=4，每个 EP Rank 持有 1/4 的 Routed Experts。

单机 H100 的可选 Peer Memory / TMA 分离执行实现、设备信号与三方测试入口见 [Peer 实验说明](PEER.md)。使用 `MINIEP_TRANSPORT=peer` 启用；`peer_dedup` 增加 Token-owner 去重分发与目标卡归约。

## 支持的模型

| 模型 | 权重 | MoE 层数 | Routed Experts | Top-K | Shared Expert |
|---|---|---:|---:|---:|---:|
| Qwen3-30B-A3B | BF16 | 48 | 128 | 8 | — |
| Qwen3.5-35B-A3B | BF16 | 40 | 256 | 8 | 1 |

## 快速开始

### 1. 环境

以下快速开始使用 4 × NVIDIA H100 80GB。双卡 RTX 4090（约 48GB/卡）的 Qwen3.5 BF16 实测、TP=1/DP=2/EP=2 启动方式和硬件限制见 [双卡 4090 报告](RTX4090.md)。软件版本：

| 组件 | 版本 |
|---|---|
| Python | 3.12 |
| vLLM | 0.29.0 |
| PyTorch | 2.13.0+cu130 |
| Triton | 3.7.1 |
| Transformers | 5.16.1 |
| CUDA / NCCL | 13.0 / 2.30.7 |
| DeepEP（仅用于对照） | 2.0.0+local |

使用对应的 vLLM 镜像启动容器：

```bash
cd routeep
export IMAGE=swr.cn-north-4.myhuaweicloud.com/ddn-k8s/docker.io/vllm/vllm-openai@sha256:082ca6f035279109041ffd3fe0695cb568b29bc580b35c4f297a66a08b216c1b
export MODEL_ROOT=/path/to/Qwen-models

docker run --rm -it --gpus '"device=0,1,2,3"' \
  --network=bridge --ipc=private --shm-size=1g \
  --cpus=8 --memory=256g --memory-swap=256g --pids-limit=1024 -p 8133:8133 \
  -e NCCL_NVLS_ENABLE=0 -e OMP_NUM_THREADS=1 -e PYTHONPATH=/workspace \
  -v "$PWD":/workspace -v "$MODEL_ROOT":/models:ro \
  -w /workspace "$IMAGE" bash
```

### 2. 安装

在容器内安装项目，并运行单元检查：

```bash
python3 -m pip install --no-deps --no-build-isolation -e .
python3 -m unittest discover -s checks -p 'test_*.py'
```

安装后，RouteEP 会通过 `vllm.general_plugins` 入口自动注册到 vLLM。

### 3. 四卡推理

```bash
export CUDA_VISIBLE_DEVICES=0,1,2,3
export NCCL_NVLS_ENABLE=0
export MODEL_PATH=/models/Qwen3-30B-A3B   # 或 /models/Qwen3.5-35B-A3B

torchrun --standalone --nproc-per-node=4 test/demo.py \
  --model "$MODEL_PATH" --backend miniep --output results/demo-qwen3
```

`--backend native` 会改用 vLLM 原生后端，便于对比。

### 4. OpenAI 兼容服务

启动服务：

```bash
export MODEL_PATH=/models/Qwen3.5-35B-A3B
python3 test/serve.py --model "$MODEL_PATH" --backend miniep \
  --dp-size 2 --host 0.0.0.0 --port 8133
```

在另一个终端检查接口：

```bash
python3 test/service_check.py --url http://127.0.0.1:8133 \
  --output results/service-check.json
```

## 性能

![RouteEP 在四张 H100 上相对 DeepEP HT 的端到端速度](assets/h100-deepep-comparison.png)

### 测量方法

- **同条件对比**：同一台 4 × H100 80GB，与 vLLM 原生 DeepEP HT 使用相同的模型、BF16 权重、请求、生成长度和 TP=2 / DP=2 / EP=4 拓扑。
- **重复测量**：每个后端独立启动三次并交替执行；每个场景预热 3 次、测量 5 次。
- **统计口径**：每次测量取四个 Rank 中最慢的端到端延迟，表中报告 15 个样本的中位数。
- **相对速度** = DeepEP HT 延迟 ÷ RouteEP 延迟 × 100%。DeepEP HT 记为 100%，越接近 100% 越快。

### 结果

| 模型 | 场景 | DeepEP HT (ms) | RouteEP (ms) | 相对速度 |
|---|---|---:|---:|---:|
| Qwen3.5 | `decode_b1` | 11393.794 | 11571.022 | **98.5%** |
| Qwen3.5 | `decode_b4` | 11428.834 | 11566.901 | **98.8%** |
| Qwen3.5 | `decode_b32` | 34653.615 | 35329.451 | **98.1%** |
| Qwen3.5 | `prefill_b1_long` | 109.425 | 141.557 | 77.3% |
| Qwen3.5 | `prefill_b4_short` | 108.457 | 122.152 | 88.8% |
| Qwen3.5 | `prefill_b4_long` | 166.576 | 199.813 | 83.4% |
| Qwen3 | `decode_b1` | 10347.186 | 11039.468 | 93.7% |
| Qwen3 | `decode_b4` | 10237.143 | 11002.575 | 93.0% |
| Qwen3 | `decode_b32` | 10292.982 | 13220.616 | 77.9% |
| Qwen3 | `prefill_b1_long` | 83.374 | 111.366 | 74.9% |
| Qwen3 | `prefill_b4_short` | 86.862 | 104.932 | 82.8% |
| Qwen3 | `prefill_b4_long` | 179.430 | 225.234 | 79.7% |

| 模型 | Decode | Prefill |
|---|---:|---:|
| Qwen3.5 | 98.1%–98.8% | 77.3%–88.8% |
| Qwen3 | 77.9%–93.7% | 74.9%–82.8% |

### Decode 与 Prefill 延迟

Decode 图是每步生成的延迟，Prefill 图是整个批次到首个 Token 的延迟。口径和上表相同。

![Qwen3 与 Qwen3.5 的 Decode 每步延迟](assets/h100-decode-latency.png)

![Qwen3 与 Qwen3.5 的 Prefill 批次延迟](assets/h100-prefill-latency.png)

从报告重新生成图表：

```bash
python3 -m pip install -r requirements-plot.txt
python3 benchmarks/plot_deepep_comparison.py
python3 benchmarks/plot_phase_latency.py
```

## 正确性

两个模型都以 vLLM DeepEP HT 后端为参照做了精确对齐：每个模型覆盖 902 条请求序列、64,164 个生成位置，全部通过。结果见 `reports/qwen3-accuracy.json` 和 `reports/qwen35-accuracy.json`。

## 双卡 RTX 4090 实测

本机 DeepEP HT 的实际初始化探测失败，因此本节采用原生 NCCL 作为替代基线；编译、CUDA IPC 与 DeepEP 运行日志见 [对照后端选择说明](DEEPEP_RTX4090.md)。

Qwen3.5-35B-A3B BF16 已在 2 × RTX 4090（约 48GB/卡）完成 TP=1/DP=2/EP=2 验收。相对本机 vLLM 原生 NCCL 对照，RouteEP 的端到端相对速度为 Decode **80.3%–86.5%**、Prefill **15.1%–23.0%**；902 条序列、64,164 个生成位置全部一致，另外 512 个同前缀位置的完整词表 logits 逐元素一致。

本机没有 NVLink，CUDA P2P 不可用，原生对照为 `allgather_reducescatter`。跨 H100 部署的自由生成并非逐 Token 一致，完整范围、阶段耗时及复现命令见 [实验报告](RTX4090.md)。该结果适用于本次约 48GB/卡的配置。

![Qwen3.5 在双卡 RTX 4090 与四卡 H100 部署下的实测延迟](assets/rtx4090-qwen35-comparison.png)

## 项目结构

```text
routeep/
├── mini_ep/       EP 推理后端：路由、分发、通信、Triton Kernel 与 vLLM 插件
├── reference/     PyTorch Reference，用于逐步核对优化实现
├── validation/    与 DeepEP 的精确对齐验证
├── checks/        单元检查与分布式检查
├── test/          推理、服务与对齐入口
├── benchmarks/    性能基准、结果汇总与绘图
├── reports/       实验数据
├── assets/        架构图、性能图与课程海报
└── tools/         海报生成脚本
```

## 配套课程

《vLLM 实战项目：大模型 MoE 专家并行实战》共 13 课，从单 GPU MoE 一路讲到接入 vLLM：

| 阶段 | 课次 | 内容 |
|---|---|---|
| MoE 基础 | 1–3 | 单 GPU MoE、Router 与 Top-K、CUDA 与 GEMM |
| 集合通信 | 4–5 | NCCL 通信、All-to-All |
| EP 系统 | 6–8 | Mini-EP V1、EP Scaling、负载均衡与 Profiling |
| Kernel 优化 | 9–12 | Triton Dispatch / Combine、Grouped GEMM、通信计算重叠 |
| vLLM 实战 | 13 | 接入 vLLM、Qwen MoE 推理、对标 DeepEP |

<p align="center"><img src="assets/poster/routeep-poster.png" alt="RouteEP 课程海报" width="480"></p>
