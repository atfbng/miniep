"""Opt-in RTX validation probes, never imported by the production Runner.

Teacher forcing compares full-vocabulary logits before substituting native
argmax values. PyTorch probes independently check all 40 real-weight MoE layers
on one decode step; probes and file IO are excluded from latency measurements.
"""

import json
from pathlib import Path

CONTROL = None
RECORDS = []
LAYERS = []


def verify_model(worker):
    """Audit all actual runners/weights once outside accuracy measurements."""
    import os
    from vllm.distributed import get_ep_group, get_dp_group, get_tp_group
    from vllm.model_executor.layers.fused_moe.runner.moe_runner import MoERunner
    from mini_ep.integration.runner import MiniEPRunner
    from benchmarks.deepep_native_backend import validate_native_backend

    worker = getattr(worker, "worker", worker)
    group = get_ep_group()
    records = []
    for runner in worker.get_model().modules():
        if not isinstance(runner, MoERunner):
            continue
        kernel = runner._quant_method.moe_kernel
        record = dict(layer=runner.layer_name, runner=type(runner).__name__,
                      manager=type(group.device_communicator.all2all_manager).__name__,
                      prepare_finalize=type(kernel.prepare_finalize).__name__,
                      experts=type(kernel.fused_experts).__name__,
                      tp_size=get_tp_group().world_size, dp_size=get_dp_group().world_size,
                      ep_size=group.world_size, local_experts=runner.routed_experts.w13_weight.shape[0],
                      weight_dtype=str(runner.routed_experts.w13_weight.dtype))
        if os.environ["MINIEP_BACKEND"] == "native":
            validate_native_backend(record, "allgather_reducescatter", (1, 2, 2))
        elif type(runner) is not MiniEPRunner:
            raise RuntimeError(f"unexpected RouteEP runner: {record}")
        if record["local_experts"] != 128 or record["weight_dtype"] != "torch.bfloat16":
            raise RuntimeError(f"unexpected local weights: {record}")
        records.append(record)
    if len(records) != 40:
        raise RuntimeError(f"expected 40 Qwen3.5 MoE layers, got {len(records)}")
    Path(os.environ["ROUTEEP_CONSUMER_OUTPUT"]).joinpath("backend.json").write_text(json.dumps(records, indent=2))
    return dict(layers=len(records), topology=[1, 2, 2])


def tensor_metrics(actual, expected, *, atol=0.1, rtol=0.01):
    import torch

    if actual.shape != expected.shape or actual.dtype != expected.dtype or actual.device != expected.device:
        raise RuntimeError("precision comparison shape/dtype/device mismatch")
    a, b = actual.float(), expected.float()
    delta = a - b
    return dict(
        shape=list(actual.shape), dtype=str(actual.dtype), device=str(actual.device),
        elements=actual.numel(), finite=bool(torch.isfinite(a).all() & torch.isfinite(b).all()),
        exact_equal=bool(torch.equal(actual, expected)),
        max_abs=float(delta.abs().max()) if delta.numel() else 0.,
        sum_abs=float(delta.abs().double().sum()),
        sum_squared=float(delta.double().square().sum()),
        outside_tolerance=int((delta.abs() > atol + rtol * b.abs()).sum()),
        atol=atol, rtol=rtol,
        top1_matches=int((a.argmax(-1) == b.argmax(-1)).sum()) if a.shape[0] else 0,
        rows=a.shape[0],
    )


def install(backend):
    import torch
    from vllm.model_executor.models.qwen3_5 import Qwen3_5MoeForConditionalGeneration

    original = Qwen3_5MoeForConditionalGeneration.compute_logits

    def capture(self, *args, **kwargs):
        logits = original(self, *args, **kwargs)
        if logits is None or CONTROL is None:
            return logits
        step = CONTROL["step"]
        CONTROL["step"] += 1
        path = Path(CONTROL["baseline"]) / f"step{step:03d}.pt"
        if backend == "native":
            path.parent.mkdir(parents=True, exist_ok=True)
            torch.save(logits.detach().cpu(), path)
            RECORDS.append(dict(step=step, shape=list(logits.shape), finite=bool(torch.isfinite(logits).all())))
            return logits
        expected = torch.load(path, map_location=logits.device, weights_only=True)
        RECORDS.append(dict(step=step, **tensor_metrics(logits, expected)))
        forced = expected.argmax(-1, keepdim=True)
        return torch.full_like(logits, -float("inf")).scatter_(-1, forced, 0.)

    Qwen3_5MoeForConditionalGeneration.compute_logits = capture
    if backend != "miniep":
        return
    from mini_ep.integration.runner import MiniEPRunner
    from mini_ep.profiler.stages import Stages
    from reference.moe import ep_forward_reference

    forward = MiniEPRunner.forward_ep
    seen = set()

    def probe(self, hidden_states, *, router_logits=None, stages=None):
        result, metadata = forward(self, hidden_states, router_logits=router_logits, stages=stages)
        # Both DP ranks enter the same reference collectives at the first decode
        # step of a balanced four-request teacher-forced batch.
        if CONTROL is not None and CONTROL["step"] == 1 and self.layer_name not in seen:
            local, routing = self.route_tokens(hidden_states, Stages(), router_logits)
            expected, _ = ep_forward_reference(
                local, routing.expert_ids, routing.routing_weights,
                self.routed_experts.w13_weight, self.routed_experts.w2_weight,
                self.ep_group,
            )
            if self._shared_experts is not None:
                expected = self._shared_experts._layer(hidden_states) + expected
            LAYERS.append(dict(layer=self.layer_name, **tensor_metrics(result, expected, atol=.02, rtol=.02)))
            seen.add(self.layer_name)
        return result, metadata

    MiniEPRunner.forward_ep = probe


def flush(root):
    root = Path(root)
    (root / "teacher-logits.json").write_text(json.dumps(RECORDS, indent=2, allow_nan=False))
    (root / "reference-layers.json").write_text(json.dumps(LAYERS, indent=2, allow_nan=False))
