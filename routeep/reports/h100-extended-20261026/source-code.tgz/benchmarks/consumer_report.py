"""Aggregate completed RTX Qwen3.5 experiments without relabeling native NCCL.

Raw input is the directory produced by consumer_suite.py. Accuracy includes
free generation, full-vocabulary teacher forcing and independent PyTorch MoE
probes; their sample counts are reported separately.
"""

import argparse
import json
import math
from pathlib import Path
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.summarize_stages import summarize


def read(path):
    return json.loads(Path(path).read_text())


def aggregate_tensors(records):
    if not records:
        raise ValueError("missing numerical comparison records")
    elements = sum(q["elements"] for q in records)
    rows = sum(q["rows"] for q in records)
    return dict(records=len(records), rows=rows, elements=elements,
                finite=all(q["finite"] for q in records),
                exact_equal=all(q["exact_equal"] for q in records),
                max_abs=max(q["max_abs"] for q in records),
                mean_abs=sum(q["sum_abs"] for q in records) / elements,
                rmse=math.sqrt(sum(q["sum_squared"] for q in records) / elements),
                outside_tolerance=sum(q["outside_tolerance"] for q in records),
                atol=records[0]["atol"], rtol=records[0]["rtol"],
                top1_matches=sum(q["top1_matches"] for q in records))


def compare_deployments(root, archive):
    """Compare identical literal inputs without treating divergent prefixes as accuracy."""
    records = []
    with tarfile.open(archive) as bundle:
        for dp in range(2):
            old = json.load(bundle.extractfile(f"trial0-miniep/rank{dp * 2}/samples.json"))
            native = json.load(bundle.extractfile(f"trial0-native/rank{dp * 2}/samples.json"))
            signature = lambda rows: [(q["case"], q["repetition"], q["token_ids"]) for q in rows]
            if signature(old) != signature(native):
                raise ValueError("historical RouteEP/native outputs differ")
            previous_inputs = json.load(bundle.extractfile(f"trial0-miniep/rank{dp * 2}/manifest.json"))
            folder = root / f"accuracy-miniep/rank{dp}"
            current = {q["key"][3:]:q["token_ids"] for q in read(folder / "outputs.json") if q["key"].startswith("s8-")}
            current_inputs = {q["name"]:q["prompts"] for q in read(folder / "manifest.json") if q["suite"] == "performance"}
            if any(q["prompts"] != current_inputs[q["name"]] for q in previous_inputs):
                raise ValueError("cross-deployment inputs differ")
            for sample in old:
                if sample["repetition"]:
                    continue
                for index, (a, b) in enumerate(zip(sample["token_ids"], current[sample["case"]], strict=True)):
                    pairs = list(zip(a, b, strict=True))
                    records.append(dict(dp=dp, case=sample["case"], request=index,
                                        generated=len(a), matching_positions=sum(x == y for x,y in pairs),
                                        common_prefix=next((i for i,(x,y) in enumerate(pairs) if x != y), len(a))))
    return dict(scope="six identical literal performance workloads; H100 TP2/DP2/EP4 versus RTX4090 TP1/DP2/EP2; free generation only",
                sequences=len(records), exact_sequences=sum(q["generated"] == q["common_prefix"] for q in records),
                positions=sum(q["generated"] for q in records), matching_positions=sum(q["matching_positions"] for q in records),
                first_token_matches=sum(q["common_prefix"] > 0 for q in records), comparisons=records,
                interpretation="Both RouteEP deployments match their own native control. After an argmax difference, later prefixes differ; positional agreement is not task accuracy or same-prefix numerical error. The topology/native backend changes have not been isolated.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--results", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--h100-checkpoint", type=Path, required=True)
    p.add_argument("--accuracy-only", action="store_true", help="summarize completed accuracy jobs while performance continues")
    a = p.parse_args()
    root, out = a.results, a.output
    progress = read(root / "progress.json")
    if a.accuracy_only:
        finished = {j["name"]:j.get("exit_code") for j in progress["jobs"]}
        if any(finished.get(name) != 0 for name in ("accuracy-native", "accuracy-miniep")):
            raise ValueError("accuracy jobs have not both completed")
    elif progress["status"] != "completed":
        raise ValueError(f"suite is incomplete: {progress['status']}")
    comparisons, logits, layers = [], [], []
    for rank in range(2):
        folder = root / f"accuracy-miniep/rank{rank}"
        if not (folder / "completed.json").exists():
            raise ValueError(f"missing candidate completion rank={rank}")
        comparisons.append(read(folder / "comparison.json"))
        logits.extend(read(folder / "teacher-logits.json"))
        current = read(folder / "reference-layers.json")
        if len(current) != 40 or len({q["layer"] for q in current}) != 40:
            raise ValueError(f"incomplete PyTorch layer coverage rank={rank}")
        layers.extend(current)
    generated = {key: sum(q[key] for q in comparisons) for key in
                 ("request_sequences", "exact_sequences", "generation_positions", "matching_positions")}
    generated["first_differences"] = [q["first_difference"] for q in comparisons]
    if (generated["request_sequences"], generated["generation_positions"]) != (902, 64164):
        raise ValueError(f"incomplete H100 workload coverage: {generated}")
    teacher = aggregate_tensors(logits)
    reference = aggregate_tensors(layers)
    checkpoint = read(root / "checkpoint.json")
    old = read(a.h100_checkpoint)["files"]
    critical = sorted(checkpoint["files"])
    changed = [name for name in critical if name not in old or
               checkpoint["files"][name]["sha256"] != old[name]["sha256"]]
    accuracy = dict(model="Qwen3.5-35B-A3B", dtype="bfloat16", topology=dict(tp=1, dp=2, ep=2),
                    native_control="vLLM allgather_reducescatter; not DeepEP",
                    checkpoint_digest=checkpoint["digest"],
                    h100_checkpoint_comparison=dict(compared_files=len(critical), changed_files=changed,
                                                    matching_weight_shards=sum(n.endswith(".safetensors") and n not in changed for n in critical)),
                    free_generation=generated, teacher_forced_full_vocabulary_logits=teacher,
                    independent_pytorch_moe=reference,
                    scope="902 request sequences reuse fresh native/candidate engines; teacher forcing separately covers 512 positions; PyTorch covers all 40 layers on one decode step per rank; not the H100 DeepEP exact protocol",
                    all_passed=(not changed and generated["exact_sequences"] == 902 and
                                generated["matching_positions"] == 64164 and teacher["finite"] and
                                teacher["outside_tolerance"] == 0 and teacher["top1_matches"] == teacher["rows"] and
                                reference["finite"] and reference["outside_tolerance"] == 0))
    out.mkdir(parents=True, exist_ok=True)
    (out / "rtx4090-qwen35-accuracy.json").write_text(json.dumps(accuracy, indent=2, allow_nan=False))
    cross = compare_deployments(root, Path(__file__).resolve().parents[1] / "reports/qwen35-primary-samples.tgz")
    (out / "rtx4090-qwen35-cross-deployment.json").write_text(json.dumps(cross, indent=2))
    if a.accuracy_only:
        print(json.dumps(accuracy, indent=2))
        return
    performance = read(root / "performance/summary.json")
    stages = dict(native=summarize(root / "performance/profile-native", False),
                  miniep=summarize(root / "performance/profile-miniep", True))
    out.mkdir(parents=True, exist_ok=True)
    performance.update(model="Qwen3.5-35B-A3B", dtype="bfloat16", topology=dict(tp=1, dp=2, ep=2),
                       hardware="2 x NVIDIA GeForce RTX 4090, 49140 MiB each, no NVLink, CUDA P2P unavailable",
                       native_control="vLLM allgather_reducescatter; not DeepEP",
                       transport_environment=progress["transport_environment"])
    for name, data in (("accuracy", accuracy), ("performance", performance), ("stages", stages)):
        (out / f"rtx4090-qwen35-{name}.json").write_text(json.dumps(data, indent=2, allow_nan=False))
    historical = read(Path(__file__).resolve().parents[1] / "reports/qwen35-performance.json")
    environment = read(root / "performance/trial0-native/rank0/environment.json")
    feasibility_path = out / "rtx4090-deepep-feasibility.json"
    if feasibility_path.exists():
        feasibility = read(feasibility_path)
        if feasibility["status"] != "deepep_unavailable_native_nccl_fallback":
            raise ValueError("unexpected DeepEP feasibility status")
        deep_ep_scope = (
            "本机已实测 DeepEP 构建与初始化：旧版 HT 成功编译为 SM89，但两 Rank 在 Buffer 初始化时均报不支持 peer access。"
            "没有产生有效 DeepEP 整模型样本，因此本报告选择 vLLM 原生 NCCL 为替代基线。"
            "实际版本范围、失败日志和源代码见 [DeepEP 验证与基线选择](DEEPEP_RTX4090.md)。"
        )
    else:
        deep_ep_scope = "本套结果的原生对照是 NCCL，没有 DeepEP 整模型对照数据。"
    lines = [
        "# 双卡 RTX 4090：Qwen3.5 性能与精度实测", "",
        "本次使用 2 × NVIDIA GeForce RTX 4090，每卡报告 49,140 MiB 显存。"
        "这是约 48GB 的配置；本结果不能作为普通双卡 24GB RTX 3090/4090 的显存验证。", "",
        "模型为 **Qwen3.5-35B-A3B BF16**，没有量化或缩减模型。"
        f"14 个权重分片以及配置、Tokenizer 等共 {len(critical)} 个文件与 H100 验收记录的 SHA-256 一致："
        f"{'全部一致' if not changed else '存在差异，见 accuracy.json'}。vLLM 实测每卡加载权重约 34.69 GiB。", "",
        "## 比较条件", "",
        "| 项目 | 本次 RTX 4090 | H100 历史测试 |",
        "|---|---|---|",
        "| GPU | 2 × RTX 4090，约 48GB/卡 | 4 × H100，80GB/卡 |",
        "| Attention / DP / MoE | TP=1 / DP=2 / EP=2 | TP=2 / DP=2 / EP=4 |",
        "| 每 Rank Routed Experts | 128 | 64 |",
        "| RouteEP 通信 | NCCL `all_to_all_single`，SHM | NCCL `all_to_all_single` |",
        "| 原生对照 | vLLM `allgather_reducescatter` | DeepEP HT |",
        "| 权重、输入、生成长度 | 与历史测试一致 | 原始配置 |",
        "| KV Cache | 512 MiB/Rank | 512 MiB/Rank |", "",
        "RTX 4090 两卡没有 NVLink，CUDA P2P 查询为 False；实际 NCCL 日志为 `SHM/direct/direct`。"
        + deep_ep_scope +
        "RouteEP 仍执行真实 All-to-All，不使用原生对照的 AllGather/ReduceScatter 实现。", "",
        "两种部署的 GPU 数、拓扑、原生对照和总 KV Cache 容量不同。"
        "H100 数据用于提供部署背景，不能将延迟比解释为单纯的 GPU 硬件性能比。"
        "4090 的 512 MiB Cache 对应约 9,216 个 Token；大批次结果包含正常调度、缓存容量及重计算的影响。", "",
        "## 性能", "",
        "每后端独立启动三次并交替执行；每场景预热 3 次、测量 5 次。"
        "每个样本取两 Rank 的最大延迟，表中报告 15 个样本的中位数。"
        "模型加载、首次 JIT、预热、结果保存和边界 collective 不计入测量。", "",
        "下表为完整生成调用的端到端时间；Decode 场景生成 128 Token，Prefill 场景生成 1 Token。"
        "相对速度 = 原生 NCCL 延迟 ÷ RouteEP 延迟 × 100%。", "",
        "| 场景（每 DP 副本） | 4090 原生 NCCL (ms) | 4090 RouteEP (ms) | 相对原生速度 | H100 RouteEP (ms) |",
        "|---|---:|---:|---:|---:|",
    ]
    for case, values in performance["cases"].items():
        native = values["native"]["e2e_ms"]["median"]
        candidate = values["miniep"]["e2e_ms"]["median"]
        previous = historical["cases"][case]["miniep"]["e2e_ms"]["median"]
        lines.append(f"| `{case}` | {native:.3f} | {candidate:.3f} | {100*native/candidate:.1f}% | {previous:.3f} |")
    lines.extend([
        "", "![两种部署配置的实测延迟](assets/rtx4090-qwen35-comparison.png)", "",
        "图中 Decode 使用每步生成延迟，Prefill 使用批次到首 Token 的延迟。"
        "误差线是 P10/P90，不是置信区间。吞吐量统计两 DP 副本的唯一请求，"
        "不重复计算 TP 复制行；完整统计和原始采样见 JSON 与归档。", "",
        "Decode 指标按整个批次最早首 Token 到最晚末 Token 的区间除以 127；"
        "缓存受限的 B32 场景包含分批调度等待，并非单个活跃请求的 TPOT。", "",
        "## 精度", "",
        f"- 自由生成：{generated['request_sequences']:,} 条序列、{generated['generation_positions']:,} 个位置；"
        f"其中 {generated['exact_sequences']:,} 条序列、{generated['matching_positions']:,} 个位置与原生 NCCL 一致。",
        f"- 同前缀完整词表 logits：单独覆盖 {teacher['rows']:,} 个生成位置，"
        f"最大绝对误差 {teacher['max_abs']:.8g}，RMSE {teacher['rmse']:.8g}；"
        f"Top-1 一致 {teacher['top1_matches']:,}/{teacher['rows']:,}，"
        f"逐元素完全一致：{'是' if teacher['exact_equal'] else '否'}。",
        f"- 独立 PyTorch MoE Reference：两 Rank 各检查全部 40 层，共 {reference['records']} 个层比较；"
        f"最大绝对误差 {reference['max_abs']:.8g}，在 atol={reference['atol']}、rtol={reference['rtol']} 下"
        f"超差元素 {reference['outside_tolerance']:,}。", "",
        "Teacher forcing 在保存实际候选 logits、计算误差之后才强制采用原生 argmax，"
        "保证后续前缀相同；自由生成另行执行。PyTorch Reference 独立实现 Dispatch、"
        "Expert MLP、All-to-All 和 Combine，验证包含真实权重及 Shared Expert 的输出。", "",
        "覆盖与 H100 相同的请求清单：相同/交错中英文语料、重复运行、请求 seed=13/37/123、"
        "边界场景、256 Token 长生成及六个性能场景。精度实验分别复用一个独立原生引擎和候选引擎；"
        "性能实验采用独立新进程。这里没有复现 H100 的全套 DeepEP 逐层精确验收协议，"
        "也没有声称对 64,164 个位置都比较了完整词表 logits。", "",
        "### 跨部署自由生成", "",
        f"另取相同字面 Token 输入的六个性能场景，与 H100 历史输出比较：{cross['sequences']} 条序列的首 Token 全部一致，"
        f"完整序列一致 {cross['exact_sequences']}/{cross['sequences']}；同位置 Token 一致 {cross['matching_positions']:,}/{cross['positions']:,}。"
        "两种部署的 RouteEP 均分别与自身原生对照完全一致。首次 argmax 差异之后，后续生成前缀已经不同，"
        "因此这里的同位置一致率不是任务准确率或同前缀数值误差率。TP/EP 拓扑、原生后端和硬件的影响未被单独隔离；"
        "本次跨部署逐 Token 精确对齐未成立。", "",
        "## 分阶段计时", "",
        "独立的 Event profiling 运行覆盖 ROUTER、DISPATCH、A2A_FORWARD、EXPERT、"
        "A2A_RETURN、COMBINE、SHARED_EXPERT、SHARED_COMBINE，详细阶段采样第 0/20/39 层，"
        "整 MoE 时间覆盖全部 40 层。计时包含数据依赖和 CPU 提交间隙，不能等同于独占 GPU Kernel 时间。"
        "若模型因调度或重计算产生额外步数，报告保留 all_calls 并列出阶段归属错误，不伪造 Prefill/Decode 分解。"
        "本次不声称通信计算重叠。", "",
        "## 环境与复现", "",
        f"软件版本：`{json.dumps(environment['versions'], ensure_ascii=False)}`；"
        f"PyTorch CUDA {environment['cuda_version']}，NCCL `{environment['nccl_version']}`。"
        "Python 3.12.11，主机 CUDA Toolkit 13.2。完整依赖冻结清单和硬件清单随原始数据保留。", "",
        "容器需要 C++ 编译器以完成 FlashInfer 首次 JIT。两后端都使用相同 NCCL 环境："
        "`NCCL_NVLS_ENABLE=0 NCCL_IB_DISABLE=1 NCCL_P2P_DISABLE=1 NCCL_CUMEM_HOST_ENABLE=0`。"
        "初始默认通信配置失败、调整后通过的日志均被保留。", "",
        "在本项目目录内，使用已安装固定依赖的 Python 环境；输出目录必须不存在：", "",
        "```bash", "export PATH=/path/to/venv/bin:$PATH",
        "export MODEL_PATH=/path/to/Qwen3.5-35B-A3B",
        'python benchmarks/consumer_suite.py --model "$MODEL_PATH" --output results/qwen35-consumer',
        "```", "",
        "汇总与绘图：", "", "```bash",
        "tar -xOf reports/qwen35-accuracy-summaries.tgz checkpoint.json > results/h100-checkpoint.json",
        "python benchmarks/consumer_report.py --results results/qwen35-consumer \\",
        "  --h100-checkpoint results/h100-checkpoint.json --output reports",
        "python benchmarks/plot_consumer_comparison.py", "```", "",
        "## 数据与验证", "",
        "- [性能统计](reports/rtx4090-qwen35-performance.json)",
        "- [精度统计](reports/rtx4090-qwen35-accuracy.json)",
        "- [阶段统计](reports/rtx4090-qwen35-stages.json)",
        "- [跨部署自由生成比较](reports/rtx4090-qwen35-cross-deployment.json)",
        "- [原始采样与验收记录](reports/rtx4090-qwen35-summaries.tgz)", "",
        "- [软件环境及测试日志](reports/rtx4090-qwen35-environment.tgz)",
        "- [执行时源码快照](reports/rtx4090-measured-source.tgz)", "",
        "- [DeepEP 实测失败证据与替代基线选择](DEEPEP_RTX4090.md)", "",
        "已执行：56 项单元测试全部通过；双 Rank NCCL/Triton 正确性测试每 Rank 48 个用例全部通过。"
        "测试覆盖 FP32/BF16、Top-1/2/8、空输入、倾斜路由、variable/fixed 布局与关键 metadata。"
        "本机只有两张 GPU，本次未执行 EP=4。", "",
    ])
    detail = stages["miniep"]["cases"]["prefill_b4_long"]["prefill"]["milliseconds_per_layer"]
    whole_native = stages["native"]["cases"]["prefill_b4_long"]["prefill"]["milliseconds_per_layer"]["whole_moe_all40"]["median"]
    whole_mini = detail["whole_moe_all40"]["median"]
    explanation = [
        "长 Prefill（每 DP 副本 4 × 2048 Token）的独立 profiling：", "",
        f"- 全部 40 层的每层 MoE 区间：原生 NCCL {whole_native:.3f} ms，RouteEP {whole_mini:.3f} ms。",
        "- 下表为第 0/20/39 层的阶段均值，逐次取最大 Rank 后再取五次中位数。", "",
        "| RouteEP 阶段 | ms/层 |", "|---|---:|",
    ]
    for stage in ("SHARED_EXPERT", "ROUTER", "DISPATCH", "A2A_FORWARD", "EXPERT", "A2A_RETURN", "COMBINE", "SHARED_COMBINE"):
        explanation.append(f"| `{stage}` | {detail[stage]['median']:.3f} |")
    explanation.extend(["", "All-to-All 阶段区间明显大于 Expert 计算区间，是当前配置长 Prefill 的主要开销。"
        "这与无 P2P、实际使用 SHM 的通信路径一致；驱动、拓扑和 NCCL 参数的影响尚未分别隔离。"
        "各阶段分别聚合，不能直接相加作为精确时间占比。", "",
        "`decode_b32` 在两后端均出现额外模型步数，阶段报告保留 `all_calls`，没有伪造其 Prefill/Decode 细分。"
        "主性能中的请求时间戳和端到端计时仍独立保留。", ""])
    at = lines.index("## 环境与复现")
    lines[at:at] = explanation
    (out.parent / "RTX4090.md").write_text("\n".join(lines))
    print(json.dumps(dict(accuracy_passed=accuracy["all_passed"],
                          performance_passed=performance["passed"],
                          free_generation=generated, teacher_logits=teacher,
                          pytorch_moe=reference), indent=2))


if __name__ == "__main__":
    main()
