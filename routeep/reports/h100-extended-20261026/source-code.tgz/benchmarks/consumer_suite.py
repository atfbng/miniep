"""Serial dual-GPU Qwen3.5 accuracy and paired latency suite.

Uses TP1/DP2/EP2, BF16, the H100 workload manifests, and native NCCL AG/RS
as the explicitly named control. RouteEP always executes NCCL All-to-All.
All checkpoint files are SHA256-hashed before launching either backend.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--model", required=True)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    model, root = Path(a.model).resolve(), Path(a.output).resolve()
    course = Path(__file__).resolve().parents[1]
    root.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, OMP_NUM_THREADS="1", NCCL_NVLS_ENABLE="0", NCCL_IB_DISABLE="1",
               NCCL_P2P_DISABLE="1", NCCL_CUMEM_HOST_ENABLE="0")
    journal = dict(status="hashing_checkpoint", started=time.time(), jobs=[],
                   transport_environment={k:v for k,v in env.items() if k.startswith("NCCL_")})

    def save():
        temporary = root / "progress.tmp"
        temporary.write_text(json.dumps(journal, indent=2))
        temporary.replace(root / "progress.json")

    save()
    def hash_file(path):
        before = path.stat()
        with path.open("rb") as stream:
            sha = hashlib.file_digest(stream, "sha256").hexdigest()
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise RuntimeError(f"checkpoint changed during hashing: {path.name}")
        print(f"HASHED {path.name}", flush=True)
        return path.name, dict(bytes=before.st_size, mtime_ns=before.st_mtime_ns, sha256=sha)

    paths = sorted(x for x in model.iterdir() if x.is_file() and x.suffix in (".json", ".safetensors", ".jinja", ".txt"))
    with ThreadPoolExecutor(max_workers=2) as pool:
        files = dict(pool.map(hash_file, paths))
    content = {name: info["sha256"] for name, info in files.items()}
    checkpoint = dict(files=files, digest=hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest(),
                      digest_kind="SHA256 of sorted filename-to-full-file-SHA256 mapping")
    manifest = root / "checkpoint.json"
    manifest.write_text(json.dumps(checkpoint, indent=2))
    commands = [
        ("accuracy-native", ["torchrun", "--standalone", "--nproc-per-node=2", "test/consumer_accuracy.py",
                             "--backend", "native", "--model", str(model), "--output", str(root / "accuracy-native")]),
        ("accuracy-miniep", ["torchrun", "--standalone", "--nproc-per-node=2", "test/consumer_accuracy.py",
                             "--backend", "miniep", "--model", str(model), "--output", str(root / "accuracy-miniep"),
                             "--reference", str(root / "accuracy-native")]),
        ("performance", [sys.executable, "benchmarks/deepep_latency.py", "--model", str(model),
                         "--output", str(root / "performance"), "--checkpoint-manifest", str(manifest),
                         "--tp-size", "1", "--all2all-backend", "allgather_reducescatter",
                         "--gpu-memory-utilization", ".94", "--kv-cache-mib", "512", "--label", "rtx4090-48gb",
                         "--trials", "3", "--warmup", "3", "--repeats", "5", "--profile-stages"]),
    ]
    journal["status"] = "running"
    for name, command in commands:
        record = dict(name=name, command=command, started=time.time())
        journal["jobs"].append(record)
        save()
        with (root / (name + ".log")).open("w") as log:
            proc = subprocess.Popen(command, cwd=course, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True)
            record["pid"] = proc.pid
            save()
            try:
                status = proc.wait(timeout=18000)
            except BaseException:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise
        record.update(exit_code=status, finished=time.time())
        if status:
            journal.update(status="failed", failed_job=name)
            save()
            return status
        save()
    journal.update(status="completed", finished=time.time())
    save()
    return 0


if __name__ == "__main__":
    sys.exit(main())
