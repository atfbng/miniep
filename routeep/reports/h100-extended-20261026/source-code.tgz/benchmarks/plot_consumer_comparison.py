"""Plot measured deployment latencies; hardware/topology/backend all explicit."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--consumer", type=Path, default=ROOT / "reports/rtx4090-qwen35-performance.json")
    p.add_argument("--h100", type=Path, default=ROOT / "reports/qwen35-performance.json")
    p.add_argument("--output", type=Path, default=ROOT / "assets/rtx4090-qwen35-comparison")
    a = p.parse_args()
    consumer = json.loads(a.consumer.read_text())
    h100 = json.loads(a.h100.read_text())
    if not consumer["passed"] or not h100["passed"]:
        raise ValueError("only accepted completed performance reports may be plotted")
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "svg.fonttype": "none"})
    fig, axes = plt.subplots(1, 2, figsize=(13.6, 5.6))
    series = [(h100, "native", "H100 / DeepEP HT", "#cbd5e1"),
              (h100, "miniep", "H100 / RouteEP", "#64748b"),
              (consumer, "native", "RTX 4090 / native NCCL AG-RS", "#fcd34d"),
              (consumer, "miniep", "RTX 4090 / RouteEP", "#d97706")]
    cases = [("decode_b1", "decode_b4", "decode_b32"),
             ("prefill_b1_long", "prefill_b4_short", "prefill_b4_long")]
    labels = [("B=1", "B=4", "B=32"),
              ("B=1, L=2048", "B=4, L=128", "B=4, L=2048")]
    for axis, names, ticks, metric, title in zip(
            axes, cases, labels, ("decode_step_ms", "prefill_batch_ms"),
            ("Decode: batch generation span / 127", "Prefill: batch time to first token"), strict=True):
        x = np.arange(3)
        for i, (report, backend, label, color) in enumerate(series):
            values = [report["cases"][n][backend][metric] for n in names]
            medians = np.array([v["median"] for v in values])
            lower = medians - np.array([v["p10"] for v in values])
            upper = np.array([v["p90"] for v in values]) - medians
            axis.bar(x + (i - 1.5) * .205, medians, .19, color=color,
                     label=label, yerr=[lower, upper], capsize=2,
                     error_kw={"elinewidth": .8, "ecolor": "#334155"})
        axis.set_xticks(x, ticks)
        axis.set_ylabel("Latency (ms), lower is better")
        axis.set_title(title, fontsize=12, loc="left", pad=15)
        axis.grid(axis="y", alpha=.18)
        axis.set_axisbelow(True)
        if metric == "prefill_batch_ms":
            axis.set_yscale("log")
            axis.set_ylim(bottom=50)
            axis.set_ylabel("Latency (ms, log scale), lower is better")
    fig.suptitle("Qwen3.5-35B-A3B / BF16: two measured deployment configurations", fontsize=15, y=.98)
    handles, legend = axes[0].get_legend_handles_labels()
    fig.legend(handles, legend, loc="lower center", bbox_to_anchor=(.5, .135), ncol=2, frameon=False)
    fig.text(.06, .085, "H100: 4 x 80 GB, TP2 / DP2 / EP4. RTX 4090: 2 x ~48 GB, TP1 / DP2 / EP2, SHM transport.", fontsize=9, color="#475569")
    fig.text(.06, .045, "Identical checkpoint and request manifests; different topology and native control. Bars: median of 15 slowest-rank samples; whiskers: p10-p90.", fontsize=8.5, color="#475569")
    fig.text(.06, .012, "Decode batch span includes scheduling and cache-capacity effects. The Prefill axis is logarithmic.", fontsize=8, color="#475569")
    fig.subplots_adjust(left=.065, right=.985, top=.84, bottom=.30, wspace=.27)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(a.output.with_suffix(".png"), dpi=220, facecolor="white")
    fig.savefig(a.output.with_suffix(".svg"), facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
