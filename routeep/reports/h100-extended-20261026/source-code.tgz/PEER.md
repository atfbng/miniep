# Peer Memory 实验路径

这条可选路径把[第 12 课的 Triton 分离执行](https://tvle9mq8jh.feishu.cn/wiki/WCOQw8Oe8iDvQUkl5gjcXS1Onke)接到 RouteEP 的 Qwen MoE：输入直接写入 Expert 所在 GPU，Up 等待设备侧就绪信号，独立 Down、回传和 Combine Kernel 完成输出。原 NCCL 路径仍是默认实现。

## 数据流与精度

`MINIEP_TRANSPORT=peer` 选择实验路径，`nccl` 选择原实现。入口位于 `mini_ep/distributed/peer.py`，GPU Kernel 位于 `mini_ep/kernels/peer_triton.py`，框架适配位于 `mini_ep/integration/runner.py`。本实现不从其他课程导入代码。

- 一进程一张本地 H100；MoE 使用调用方提供的 NCCL EP group。`ep_rank` 是组内编号，指针表也按 EP rank 排列，不以 CUDA device 编号寻址。支持 EP=1/2/4 的验证入口。
- 输入是连续 BF16 `[N,H]`，全局 Expert ID 是连续 int64 `[N,K]`，路由权重是连续 FP32 `[N,K]`。本地权重保持 vLLM 的 `[L,2F,H]`、`[L,H,F]` 布局，均匀放置 `E=P*L`。
- 先稳定排序原始分支编号，汇总每来源/每 Expert 的计数 `[P,E]`。这里只有整数 metadata AllGather；Token 不做 AllGather，也不做 Tensor Parallel MoE。排序、计数、交换和地址规划每轮执行，计入动态前向。
- GPU 上的前缀和确定每 Expert 的紧凑接收段，以及每来源在段内的起点。各来源直接写入不重叠的 Expert-major 输入行，省去原实现接收后的排序和 Token 重排。
- 每个 16 行 × 256 列的输入复制 CTA 发布完成计数；每个 Expert 的 BM=128 Tile 等待其全部有效行/列片段完成。system-scope acq_rel 原子操作连接各生产者的写入，Up 通过 acquire 等待后读取输入。
- TMA Up 同时计算 gate/up，并融合 SwiGLU；BF16 Up、BF16 SiLU、BF16 激活乘法的舍入位置沿用 Reference。Down 复用原 Grouped GEMM，保持 FP32 累加、FP32 路由权重乘法和 BF16 返回。
- 每条接收行携带 `(源 EP rank, 原始 token-major 分支编号)`。回传按该地址写入源 GPU；原 Combine 保留逐分支、逐 owner 的 BF16 舍入和升序 owner FP32 合并。

与文档教学实现的区别：GELU/FP16/Top-1/2 改为 BF16 SwiGLU/任意合法 Top-K；固定路由的 CPU 准备改为逐层动态 GPU metadata；每 Expert 固定容量改为紧凑布局。工作区的安全上界是 `P*max(source_rows)*K`，不为每个 Expert 都分配该上界。

## 生命周期与限制

所有调用使用构造时的同一 CUDA stream。开始信号在上一轮 Combine 之后发布，所有来源都读完旧缓冲、清零就绪计数后，才允许新一轮输入写入。Up/Down/回传按本地流顺序执行；回传结束后，各 Rank 发布并等待完成信号，再读取 returned 做 Combine。Python 返回表示已提交 GPU 工作；这些设备信号和流顺序保证数据可读，不能用 Python 返回代替 GPU 完成。

模型的各层共享按来源行数 2 的幂分桶的工作区，路由和 Expert 权重每次重新传入。Host 来源行数由 vLLM 的 DP metadata 提供。首次进入一个容量桶时映射和同步，属于准备成本；如果发生在测量请求内，就计入端到端时间。大 prefill 缓冲不用于单 Token decode，避免启动大量无效 Tile；主体数据容量按几何级数增长，小桶另有 BM=128 对齐和固定 metadata 开销。单层基准明确把工作区构造/JIT 放在预热前。返回结果由 Combine 新分配，可跨轮保留；跨流消费仍需要调用方的 CUDA Event 依赖。销毁进程组前调用 `clear_peer_workspaces()` 排空并释放映射。

当前实验要求单机 Peer 访问及跨 GPU 原子操作、SM≥90、BF16、E 为 2 的幂、H 为 8 的倍数、F 为 128 的倍数。工作区不可并发重入；跨流复用直接报错。没有跨节点、CUDA Graph、FP8 或训练支持。PyTorch symmetric-memory 与 Triton TensorDescriptor 是版本相关接口，实测软件环境写入结果 JSON。

这些独立 Kernel 不构成同 GPU 上的通信计算融合。可能与对端发送交叠的部分需要 Nsight Systems Timeline 验证；CUDA Event 总延迟降低本身不足以证明 overlap。

## 复现

在已配置 vLLM/DeepEP 的 H100 环境中，从 `routeep/` 运行。`CUDA_VISIBLE_DEVICES` 选择本任务可用的卡。

```bash
# 真实 NCCL / Peer 正确性：同样命令分别使用 1、2、4 个进程。
torchrun --standalone --nproc-per-node=4 checks/peer.py --output results/peer-correctness
python3 -m unittest discover -s checks -p 'test_*.py'

# 动态 MoE 层；同一 tokens/IDs/weights，包含各自 dispatch / metadata。
torchrun --standalone --nproc-per-node=4 benchmarks/peer_latency.py \
  --tokens 1 8 128 1024 --hidden 2048 --intermediate 512 \
  --experts 256 --top-k 8 --warmup 10 --repeats 30 --output results/peer-layer

# vLLM 正常推理中的实验开关。
MINIEP_TRANSPORT=peer torchrun --standalone --nproc-per-node=4 test/demo.py \
  --model /models/Qwen3.5-35B-A3B --backend miniep --output results/peer-demo

# 三方整模型基准。manifest-dir 放置各模型的 <模型目录名>-checkpoint.json，
# 使用 test/deepep_alignment.py 的 checkpoint_manifest() 生成实际文件 SHA256。
python3 benchmarks/peer_suite.py \
  --models /models/Qwen3.5-35B-A3B /models/Qwen3-30B-A3B \
  --manifest-dir /experiment --output results/peer-three-way
```

三方基准保持 BF16、eager、TP=2/DP=2/EP=4、相同 checkpoint、字面 Token 输入和生成长度。权重使用 lazy 加载，避免后台预取线程进入测量；统一 4 GiB KV Cache，避免 32 请求因小缓存而分批执行。每个模型执行三个独立 trial，每轮轮换 NCCL RouteEP、Peer RouteEP、原生 DeepEP HT 的执行顺序；每个配置新建进程和引擎，预热后重复三次。每次取最大 Rank 延迟，再报告九个样本的中位数。报告区分端到端、prefill 和 decode step，保留各 Rank 原始样本、实际后端证明、源文件哈希、环境与 GPU 状态。

## Token-owner 去重与目标卡归约

原 NCCL 打包与 `peer` 路径都以 Expert 分支为传输单位。同一个 Token 的多个 Expert 位于同一目标 Rank 时，输入重复传输；返回也逐分支发送，在来源 Rank 上完成 owner 合并。

已用实际 `pack_by_destination_rank()` 复现用户示例：E=256、EP=2、Top-8，`ids=[0,1,2,3,128,129,130,131]`，发往 Rank 1 的确是四份 `[1,2]`。H=2048/BF16 时，该 Token 的远端大向量往返逻辑载荷是 32 KiB。默认小批次 NCCL 固定容量路径还会包含 padding；本例 C=8 时接口提交的大向量往返缓冲为 64 KiB。以上均不含 metadata、信号与链路协议开销。

`MINIEP_TRANSPORT=peer_dedup` 选择新增路径，入口为 `mini_ep/distributed/peer_dedup.py`，Kernel 为 `mini_ep/kernels/peer_dedup_triton.py`：

1. 每个 `(来源 EP rank, 原 Token, 目标 EP rank)` 只传一份 BF16 输入。Expert 分支的整数身份和 FP32 权重仍独立传输。
2. 每个来源的输入复制 Kernel 结束后，metadata Kernel 发布目标 Expert Tile 的就绪计数。目标 GPU acquire 该计数后，在卡内展开给本地 Expert；再使用相同的 TMA Up/SwiGLU 和 weighted Down。没有增加全局输入完成屏障。
3. Down 仍逐分支产生已加权 BF16 输出。目标 GPU 根据 `row_lookup[source,token,slot]`，严格按原始 slot 顺序以 FP32 累加该 owner 的分支，再舍入一次为 BF16。每个 Token/owner 只回传一个向量。
4. 来源 GPU 按 owner EP rank 升序以 FP32 累加这些 BF16 owner 部分和，最后转 BF16。此处不再次乘权重。

在同一示例中，分发和回传各一份 4 KiB 向量，往返为 8 KiB；四个远端 Expert 的计算量保持不变。不能将 owner 内的累加改为逐次 BF16 加法或无序浮点原子求和，否则会改变原有精度规则。定向精度检查包含 `[256,1,-256,1]`：按原 FP32 累加规则 owner 结果应为 2。

工作区新增 `unique_inputs[P*C,H]`、`row_lookup[P*C,K]` 和 `owner_returned[P*C,H]`，C 为准备容量中的每来源最大 Token 数。前两者按 source/token 排列，返回缓冲按 owner/token 排列；输入和返回 BF16，lookup 为 int64，metadata 就绪计数为 int32。开始信号在新一轮覆盖前保护所有来源的上轮输出读取；结束信号发布目标卡归约回传完成。仍要求同一 CUDA stream 和一致的 EP 调用顺序。

本次按任务限定，只补充去重版本的精度与整模型性能，沿用已完成的 `peer`、原 NCCL 和 DeepEP 对照，不再额外运行微基准或 Timeline：

```bash
# 新路径的定向精度，分别用 2 / 4 张 H100；包含原 Peer 和 PyTorch 对照。
torchrun --standalone --nproc-per-node=2 checks/peer_dedup.py --output results/dedup-accuracy-ep2
torchrun --standalone --nproc-per-node=4 checks/peer_dedup.py --output results/dedup-accuracy-ep4

# 每模型三个新引擎，只补跑 peer_dedup；自动核对原 peer 的请求和生成 Token。
python3 benchmarks/peer_dedup_suite.py \
  --models /models/Qwen3.5-35B-A3B /models/Qwen3-30B-A3B \
  --manifest-dir /experiment --baseline /experiment/three-way-final \
  --output results/peer-dedup-performance
```

补测与原对照使用相同 GPU、镜像、BF16、eager、TP=2/DP=2/EP=4、4 GiB KV Cache、输入和生成长度，以及预热/重复次数。去重补测在原对照之后执行，未与旧版本交替重跑。性能结论以实际延迟为准；大向量数量减少不等同于所有负载都会更快。

两模型的最终四方性能、精度、重复传输确认和原始数据见 [H100 去重实测报告](reports/h100-peer-dedup-20261026/REPORT.md)。
