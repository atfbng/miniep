"""Independent token/owner packing via literal Python loops, for CPU/CUDA tests."""
import torch
from mini_ep.distributed.dedup import TokenOwnerPack
from mini_ep.distributed.topology import ExpertParallelTopology


def pack_token_owners_reference(tokens, ids, weights, topology: ExpertParallelTopology):
    """One vector per used token/owner, preserving original slot identities."""
    rows, packed_ids, packed_weights, counts = [], [], [], []
    n, k = ids.shape
    restore = torch.full((topology.ep_size, n), -1, device=tokens.device, dtype=torch.long)
    for owner in range(topology.ep_size):
        count = 0
        for token in range(n):
            slots = [s for s in range(k) if int(ids[token, s]) // topology.num_local_experts == owner]
            if slots:
                restore[owner, token] = len(rows)
                rows.append(tokens[token])
                one_ids = torch.full((k,), -1, device=tokens.device, dtype=torch.long)
                one_weights = weights.new_zeros(k)
                for slot in slots:
                    one_ids[slot] = ids[token, slot]
                    one_weights[slot] = weights[token, slot]
                packed_ids.append(one_ids);packed_weights.append(one_weights);count += 1
        counts.append(count)
    return TokenOwnerPack(
        torch.stack(rows) if rows else tokens.new_empty((0, tokens.shape[1])),
        torch.stack(packed_ids) if rows else ids.new_empty((0, k), dtype=torch.long),
        torch.stack(packed_weights) if rows else weights.new_empty((0, k)),
        torch.tensor(counts, device=tokens.device), restore,
    )
