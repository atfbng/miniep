"""Owner-deduplicated peer payloads; per-Expert metadata stays branch-granular.

All allocations/pointer tables belong to distributed.peer_dedup. BF16 payloads
use contiguous [row,H]. Metadata is int64, routing weights are FP32. Source
identity is (EP rank, original token, slot); global ranks/device IDs are not
used as peer pointer indices. No floating-point atomic reduction is used.
"""
import triton
import triton.language as tl
from mini_ep.kernels.peer_triton import _wait


@triton.jit
def send_unique_kernel(X, Ids, InputPtrs, N, H: tl.constexpr, K: tl.constexpr,
                       L: tl.constexpr, C: tl.constexpr, RANK: tl.constexpr,
                       BK: tl.constexpr, BH: tl.constexpr):
    """Original X[N,H], Ids[N,K] -> one remote X per (token,owner).

    Each owner's input buffer [P*C,H] is source-major/original-token-major.
    BM=16 rows per copy CTA; K is only metadata and is never expanded in X.
    """
    token = tl.program_id(0) * 16 + tl.arange(0, 16)
    owner = tl.program_id(1)
    col = tl.program_id(2) * BH + tl.arange(0, BH)
    slots = tl.arange(0, BK)
    expert = tl.load(Ids + token[:, None] * K + slots[None, :],
                     (token[:, None] < N) & (slots[None, :] < K), -1)
    owns = tl.sum(((expert // L == owner) & (expert >= 0)).to(tl.int32), 1) > 0
    ptr = tl.load(InputPtrs + owner).to(tl.pointer_type(X.dtype.element_ty))
    valid = (token[:, None] < N) & owns[:, None] & (col[None, :] < H)
    value = tl.load(X + token[:, None] * H + col[None, :], valid, 0)
    tl.store(ptr + (RANK * C + token[:, None]) * H + col[None, :], value, valid)


@triton.jit
def send_metadata_kernel(Ids, Weights, Order, Starts, Targets,
                         MetaPtrs, WeightPtrs, LookupPtrs, ReadyPtrs, SourceRows, TileStarts, B,
                         K: tl.constexpr, L: tl.constexpr, C: tl.constexpr,
                         RANK: tl.constexpr, BM: tl.constexpr, BLOCK: tl.constexpr):
    """Sorted branch identities -> Expert-major metadata and inverse slot map.

    Remote Meta[R,2]=(source EP rank, original branch), Weights[R] FP32;
    Lookup[P*C,K] int64 maps source token/slot to the receiver's Expert row.
    Lookup was initialized to -1 before the start barrier. Only owned slots
    are filled; other slots and unused source-token capacity remain -1.
    """
    row = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = row < B
    branch = tl.load(Order + row, valid, 0)
    expert = tl.load(Ids + branch, valid, 0)
    owner = expert // L
    target = tl.load(Targets + expert) + row - tl.load(Starts + expert)
    meta = tl.load(MetaPtrs + owner).to(tl.pointer_type(tl.int64))
    routing = tl.load(WeightPtrs + owner).to(tl.pointer_type(tl.float32))
    lookup = tl.load(LookupPtrs + owner).to(tl.pointer_type(tl.int64))
    tl.store(meta + target * 2, RANK, valid)
    tl.store(meta + target * 2 + 1, branch, valid)
    tl.store(routing + target, tl.load(Weights + branch, valid, 0), valid)
    tl.store(lookup + RANK * C * K + branch, target, valid)
    # Unique-input copy is a preceding kernel on the source stream. Publishing
    # metadata now releases that input plus this branch's metadata to the owner.
    tl.debug_barrier()
    ready = tl.load(ReadyPtrs + owner).to(tl.pointer_type(tl.int32))
    expert_row = tl.load(SourceRows + expert) + row - tl.load(Starts + expert)
    tile = tl.load(TileStarts + expert) + expert_row // BM
    tl.atomic_add(ready + tile, 1, mask=valid, sem="acq_rel", scope="sys")


@triton.jit
def expand_local_kernel(Unique, Meta, Data, Offsets, Experts, Rows, Ready, MetaReady, Expected,
                        H: tl.constexpr, K: tl.constexpr, C: tl.constexpr,
                        BM: tl.constexpr, BH: tl.constexpr):
    """Local [P*C,H] unique inputs -> compact Expert-major Data[R,H].

    Acquires this tile's metadata count, which releases preceding unique-input
    writes as well. The copies below
    stay on this GPU; Top-K expansion consumes no further NVLink payload.
    Publishes the same tile-ready counts consumed by the existing TMA Up.
    """
    tile = tl.program_id(0)
    expert = tl.load(Experts + tile)
    if expert < 0:
        return
    _wait(MetaReady + tile, tl.load(Expected + tile) // tl.cdiv(H, BH))
    row = tl.load(Offsets + expert) + tl.load(Rows + tile) + tl.program_id(1) * 16 + tl.arange(0, 16)
    end = tl.load(Offsets + expert + 1)
    col = tl.program_id(2) * BH + tl.arange(0, BH)
    source = tl.load(Meta + row * 2, row < end, 0)
    branch = tl.load(Meta + row * 2 + 1, row < end, 0)
    valid = (row[:, None] < end) & (col[None, :] < H)
    value = tl.load(Unique + (source[:, None] * C + branch[:, None] // K) * H + col[None, :], valid, 0)
    tl.store(Data + row[:, None] * H + col[None, :], value, valid)
    tl.debug_barrier()
    tl.atomic_add(Ready + tile, tl.sum((row < end).to(tl.int32), 0), sem="acq_rel", scope="sys")


@triton.jit
def push_owner_partials_kernel(Outputs, Lookup, ReturnPtrs,
                               H: tl.constexpr, K: tl.constexpr, C: tl.constexpr,
                               P: tl.constexpr, RANK: tl.constexpr, BH: tl.constexpr):
    """Weighted BF16 Expert rows -> one BF16 vector per (source token,owner).

    Lookup[P*C,K] supplies Expert row IDs, -1 for slots owned elsewhere. Sum
    rounded branches in ascending original slot order, in FP32, then round
    once to BF16 at the owner boundary. This is exactly the existing Combine
    rule moved to the owner GPU; do not accumulate branches in BF16.
    """
    pair = tl.program_id(0) * 16 + tl.arange(0, 16)
    source = pair // C
    token = pair % C
    col = tl.program_id(1) * BH + tl.arange(0, BH)
    partial = tl.full((16, BH), 0.0, tl.float32)
    any_owned = tl.full((16,), False, tl.int1)
    for slot in tl.static_range(K):
        row = tl.load(Lookup + pair * K + slot, pair < P * C, -1)
        valid = (pair[:, None] < P * C) & (row[:, None] >= 0) & (col[None, :] < H)
        value = tl.load(Outputs + row[:, None] * H + col[None, :], valid, 0).to(tl.float32)
        partial = partial + value
        any_owned = any_owned | (row >= 0)
    ptr = tl.load(ReturnPtrs + source, pair < P * C, 0).to(tl.pointer_type(Outputs.dtype.element_ty))
    tl.store(ptr[:, None] + (RANK * C + token[:, None]) * H + col[None, :], partial,
             (pair[:, None] < P * C) & any_owned[:, None] & (col[None, :] < H))


@triton.jit
def combine_owner_partials_kernel(Returned, Ids, Output, N,
                                  H: tl.constexpr, K: tl.constexpr,
                                  C: tl.constexpr, P: tl.constexpr,
                                  L: tl.constexpr, BLOCK: tl.constexpr):
    """BF16 Returned[P*C,H] -> original BF16 Output[N,H].

    Read only owners selected by the original [N,K] route (other buffer rows
    need not be initialized). Owner contributions accumulate FP32 in ascending
    EP-rank order, followed by the original single model-dtype output store.
    """
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    token, col = idx // H, idx % H
    valid = idx < N * H
    total = tl.full((BLOCK,), 0.0, tl.float32)
    for owner in tl.static_range(P):
        owns = tl.full((BLOCK,), False, tl.int1)
        for slot in tl.static_range(K):
            expert = tl.load(Ids + token * K + slot, valid, 0)
            owns = owns | (expert // L == owner)
        value = tl.load(Returned + (owner * C + token) * H + col, valid & owns, 0)
        total = total + value.to(tl.float32)
    tl.store(Output + idx, total, valid)
