"""Choose communication only; deduplication is always enabled in the Runner."""
import os
from typing import Callable


def get_transport() -> str:
    """Default to portable NCCL; peer selects the optional TMA implementation.

    The historical peer_dedup value remains an alias for peer. It no longer
    represents a separate algorithm, and no deduplication toggle is provided.
    """
    name = os.environ.get("MINIEP_TRANSPORT", "nccl")
    if name == "peer_dedup":
        return "peer"
    if name not in ("nccl", "peer"):
        raise ValueError(f"MINIEP_TRANSPORT must be nccl/peer, got {name!r}")
    return name


def get_peer_forward(transport: str) -> Callable | None:
    """NCCL imports no peer code; peer always resolves the deduplicated path."""
    if transport == "nccl":
        return None
    if transport in ("peer", "peer_dedup"):
        from mini_ep.distributed.peer_dedup import deduplicated_peer_forward

        return deduplicated_peer_forward
    raise ValueError(f"unknown transport {transport!r}")
