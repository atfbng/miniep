"""Transport-independent token/owner packing and ordered partial reductions.

These PyTorch layout operations run on CPU or CUDA. They do not import Triton,
peer memory, or a process group. IDs are global; placement is uniform E=P*L.
"""
from dataclasses import dataclass

import torch

from mini_ep.distributed.dispatch import _validate
from mini_ep.distributed.topology import ExpertParallelTopology


@dataclass(frozen=True)
class TokenOwnerPack:
    """Destination-major unique [U,H] vectors, token-major within each owner.

    IDs [U,K] int64 preserve original slots, with -1 for other owners; FP32
    weights [U,K] are zero in those slots. Splits [P] int64 count unique rows,
    not branches or bytes. restore_index [P,N] int64 maps (owner, original
    token) to its returned row, or -1 when absent. All fields are contiguous
    and share the input device; vector dtype follows the input.
    """
    packed_tokens: torch.Tensor
    packed_expert_ids: torch.Tensor
    packed_routing_weights: torch.Tensor
    send_splits: torch.Tensor
    restore_index: torch.Tensor


def pack_token_owners(
    tokens: torch.Tensor, expert_ids: torch.Tensor,
    routing_weights: torch.Tensor, topology: ExpertParallelTopology,
) -> TokenOwnerPack:
    """Unexpanded [N,H], [N,K] -> one input for each used (token, owner).

    Strided inputs are accepted. Dynamic unique counts can synchronize on CUDA;
    this readable variable-split path does not claim an asynchronous pipeline.
    Outer model validation checks ID range and finite nonnegative weights.
    """
    _validate(tokens, expert_ids, routing_weights)
    n, k = expert_ids.shape
    base = max(n, 1)
    destinations = topology.destination_rank(expert_ids)
    token_rows = torch.arange(n, device=tokens.device)[:, None].expand(n, k)
    keys = torch.unique((destinations * base + token_rows).reshape(-1), sorted=True)
    owners, source_tokens = keys // base, keys % base
    selected_ids = expert_ids.long().index_select(0, source_tokens)
    belongs = topology.destination_rank(selected_ids) == owners[:, None]
    packed_ids = torch.where(belongs, selected_ids, -1).contiguous()
    packed_weights = torch.where(
        belongs, routing_weights.index_select(0, source_tokens), 0.0,
    ).contiguous()
    restore = torch.full((topology.ep_size, n), -1, dtype=torch.int64, device=tokens.device)
    restore[owners, source_tokens] = torch.arange(keys.numel(), device=tokens.device)
    return TokenOwnerPack(
        tokens.index_select(0, source_tokens).contiguous(), packed_ids, packed_weights,
        torch.bincount(owners, minlength=topology.ep_size), restore,
    )


def expand_owner_branches(
    tokens: torch.Tensor, expert_ids: torch.Tensor, routing_weights: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Received source-major [U,H]/[U,K] -> local [R,H] expert branches.

    Valid slots are expanded in unique-row then original-slot order. Returns
    contiguous tokens [R,H], global IDs [R] int64, weights [R] FP32 and lookup
    [U,K] int64 (branch row, or -1). No payload crosses a GPU boundary here.
    """
    valid = expert_ids >= 0
    pair_rows, slots = torch.where(valid)
    lookup = torch.full_like(expert_ids, -1, dtype=torch.int64)
    lookup[pair_rows, slots] = torch.arange(pair_rows.numel(), device=tokens.device)
    return (
        tokens.index_select(0, pair_rows).contiguous(),
        expert_ids[pair_rows, slots].long().contiguous(),
        routing_weights[pair_rows, slots].contiguous(), lookup,
    )


def reduce_owner_branches(
    weighted_branches: torch.Tensor, lookup: torch.Tensor, *, model_dtype: torch.dtype,
) -> torch.Tensor:
    """Preweighted [R,H] -> model-dtype [U,H] owner partials, before return.

    Round each branch to model dtype, accumulate FP32 in original slot order,
    then round each owner partial once. This matches the original source-side
    owner boundary, including an explicitly requested branch return dtype.
    No unordered atomic accumulation or second application of weights occurs.
    """
    total = torch.zeros(
        (lookup.shape[0], weighted_branches.shape[1]),
        dtype=torch.float32, device=weighted_branches.device,
    )
    if weighted_branches.shape[0]:
        branches = weighted_branches.to(model_dtype)
        for slot in range(lookup.shape[1]):
            rows = lookup[:, slot]
            values = branches.index_select(0, rows.clamp_min(0)).float()
            total = total + torch.where(rows[:, None] >= 0, values, 0.0)
    return total.to(model_dtype)


def combine_owner_partials(returned: torch.Tensor, restore_index: torch.Tensor) -> torch.Tensor:
    """Returned unique [U,H] -> original [N,H], ascending-owner FP32 sum.

    restore_index [P,N] comes from the source pack. Input already contains
    weighted, model-rounded owner partials. Output follows returned dtype and
    device. Missing owners contribute zero, including entirely empty sources.
    """
    total = torch.zeros(
        (restore_index.shape[1], returned.shape[1]),
        dtype=torch.float32, device=returned.device,
    )
    if returned.shape[0]:
        for owner in range(restore_index.shape[0]):
            rows = restore_index[owner]
            values = returned.index_select(0, rows.clamp_min(0)).float()
            total = total + torch.where(rows[:, None] >= 0, values, 0.0)
    return total.to(returned.dtype)
