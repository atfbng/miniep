"""Peer EP with one payload per (source token, owner), and owner-side combine.

Reference: reference.moe.moe_reference / reference.dispatch.owner_partials_reference.
The same BF16 TMA Up/SwiGLU and weighted grouped Down are reused unchanged.
"""
from __future__ import annotations

import torch
import torch.distributed as dist
import torch.distributed._symmetric_memory as symm
import triton
from triton.tools.tensor_descriptor import TensorDescriptor

from mini_ep.distributed.peer import PeerSwiGLU
from mini_ep.model.contracts import validate_inputs
from mini_ep.profiler.stages import Stages
from mini_ep.kernels.peer_triton import _layout, _plan, _signal, _up
from mini_ep.kernels.grouped_gemm.triton_impl import grouped_gemm
from mini_ep.kernels.peer_dedup_triton import (
    send_unique_kernel, send_metadata_kernel, expand_local_kernel,
    push_owner_partials_kernel, combine_owner_partials_kernel,
)


class DeduplicatedPeerSwiGLU(PeerSwiGLU):
    """Single-node BF16 EP, with the base class's group/stream/layout contracts.

    C=max prepared source tokens. Extra symmetric buffers are unique_inputs
    [P*C,H] BF16 (source-major, original tokens), row_lookup [P*C,K] int64
    (source/token/slot -> this owner's compact Expert row, -1 if not owned),
    owner_returned [P*C,H] BF16 (owner-major, original source tokens), and
    metadata_ready[tile_capacity] int32 counters.

    GPU sources write each (token, destination EP rank) input once. Integer
    branch identities/FP32 weights still travel per Expert branch. Per-tile system
    release/acquire metadata signals hand off preceding unique-input writes to
    GPU-local expansion into the compact Expert-major workspace. Expert MLP and weighting are unchanged.

    Return reduces already-rounded BF16 branches sequentially by slot in FP32,
    rounds the owner sum once to BF16 and sends a single vector. The source
    adds owner sums in ascending EP-rank FP32 order and casts its final output.
    No BF16 incremental sum, unordered atomic sum, or early routing weighting
    is introduced. Output buffers and flags use the same single CUDA stream.

    Begin/finish flags use epoch, as in the base path. Metadata counts reset
    before the start barrier. Each source's input-copy kernel precedes metadata
    publication; local expansion acquires its tile's branch count, then publishes
    the base TMA-ready counter. No all-rank input-completion barrier is added.
    All peers participate even with no local tokens. Drain before destroying the
    group; cross-stream calls are rejected.
    """
    def __init__(self, group: dist.ProcessGroup, hidden: int, local_experts: int,
                 top_k: int, source_rows: list[int], device: torch.device) -> None:
        super().__init__(group, hidden, local_experts, top_k, source_rows, device)
        self.c = self.source_limit
        specs = [((self.p * self.c, self.h), torch.bfloat16),
                 ((self.p * self.c, self.k), torch.int64),
                 ((self.p * self.c, self.h), torch.bfloat16),
                 ((self.experts.numel(),), torch.int32)]
        self.dedup_buffers = [symm.empty(*shape, dtype=dtype, device=device) for shape,dtype in specs]
        self.unique_inputs, self.row_lookup, self.owner_returned, self.metadata_ready = self.dedup_buffers
        self.dedup_handles = [symm.rendezvous(t, group) for t in self.dedup_buffers]
        self.dedup_ptrs = [torch.tensor(h.buffer_ptrs, dtype=torch.uint64, device=device) for h in self.dedup_handles]
        torch.cuda.synchronize(device)
        dist.barrier(group)

    def forward(self, tokens: torch.Tensor, ids: torch.Tensor, weights: torch.Tensor,
                w13: torch.Tensor, w2: torch.Tensor, *, stages: Stages | None = None,
                validate: bool = True) -> tuple[torch.Tensor, dict]:
        if validate:
            validate_inputs(tokens, ids, weights, w13, w2, self.topology)
        if (tokens.dtype != torch.bfloat16 or tokens.device != self.device
            or ids.dtype != torch.int64 or ids.shape[1] != self.k
            or tokens.shape[1] != self.h or w13.shape[0] != self.l
            or tokens.shape[0] > self.source_limit
            or weights.dtype != torch.float32 or weights.shape != ids.shape
            or w13.dtype != tokens.dtype or w2.dtype != tokens.dtype
            or any(t.device != tokens.device for t in (ids,weights,w13,w2))
            or not all(t.is_contiguous() for t in (tokens,ids,weights,w13,w2))):
            raise ValueError('deduplicated peer requires contiguous CUDA BF16 payload/weights, int64 IDs, FP32 routing weights within prepared H/L/K/N')
        if w2.shape[2] % 128:
            raise ValueError(f'TMA fused Up requires F divisible by 128, got {w2.shape[2]}')
        if torch.cuda.current_stream(self.device).cuda_stream != self.stream:
            raise RuntimeError('deduplicated peer calls must use the construction CUDA stream')
        if self.epoch >= 2**31 - 1:
            raise RuntimeError('peer phase counter exhausted; drain and recreate workspace')
        stages = stages or Stages()
        self.epoch += 1
        with stages.stage('DISPATCH'):
            flat = ids.view(-1)
            order = torch.argsort(flat, stable=True)
            counts = torch.bincount(flat, minlength=self.e)
            dist.all_gather_into_tensor(self.counts.view(-1), counts, group=self.group)
            _layout[(1,)](self.counts,self.starts,self.targets,self.source_prefixes,self.tile_starts,self.offsets,
                self.e,self.p,self.l,self.rank,128,self.e,triton.next_power_of_2(self.p))
            _plan[(1,)](self.offsets,self.experts,self.rows,self.expected,self.l,128,
                self.experts.numel(),triton.next_power_of_2(self.l),
                triton.next_power_of_2(self.experts.numel()),triton.cdiv(self.h,256))
            self.ready.zero_()
            self.row_lookup.fill_(-1)
            self.metadata_ready.zero_()
            _signal[(1,)](self.ptrs[5],self.epoch,self.p,self.rank,False)
        with stages.stage('A2A_FORWARD'):
            if flat.numel():
                send_unique_kernel[(triton.cdiv(tokens.shape[0],16),self.p,triton.cdiv(self.h,256))](
                    tokens,flat,self.dedup_ptrs[0],tokens.shape[0],self.h,self.k,self.l,
                    self.c,self.rank,triton.next_power_of_2(self.k),256)
                send_metadata_kernel[(triton.cdiv(flat.numel(),256),)](
                    flat,weights,order,self.starts,self.targets,self.ptrs[1],self.ptrs[2],
                    self.dedup_ptrs[1],self.dedup_ptrs[3],self.source_prefixes,self.tile_starts,
                    flat.numel(),self.k,self.l,self.c,self.rank,128,256)
            expand_local_kernel[(self.experts.numel(),8,triton.cdiv(self.h,256))](
                self.unique_inputs,self.meta,self.data,self.offsets,self.experts,self.rows,
                self.ready,self.metadata_ready,self.expected,self.h,self.k,self.c,128,256)
        with stages.stage('EXPERT'):
            f = w2.shape[2]
            activated = torch.empty((self.capacity,f),dtype=tokens.dtype,device=self.device)
            input_desc = TensorDescriptor(self.data,[self.capacity,self.h],[self.h,1],[128,64])
            weight_desc = TensorDescriptor(w13,[self.l*2*f,self.h],[self.h,1],[128,64])
            _up[(self.experts.numel(),triton.cdiv(f,128))](input_desc,weight_desc,activated,
                self.offsets,self.experts,self.rows,self.ready,self.expected,f,self.h,128,128,64,
                num_warps=8,num_stages=3,enable_fp_fusion=False)
            expert_outputs = grouped_gemm(activated,w2,self.plan,output_dtype=tokens.dtype,row_weights=self.weights)
        with stages.stage('A2A_RETURN'):
            push_owner_partials_kernel[(triton.cdiv(self.p*self.c,16),triton.cdiv(self.h,256))](
                expert_outputs,self.row_lookup,self.dedup_ptrs[2],self.h,self.k,self.c,
                self.p,self.rank,256,enable_fp_fusion=False)
            _signal[(1,)](self.ptrs[5],self.epoch,self.p,self.rank,True)
        with stages.stage('COMBINE'):
            result = torch.empty_like(tokens)
            if tokens.numel():
                combine_owner_partials_kernel[(triton.cdiv(tokens.numel(),256),)](
                    self.owner_returned,ids,result,tokens.shape[0],self.h,self.k,self.c,
                    self.p,self.l,256,enable_fp_fusion=False)
        return result,dict(transport='peer',deduplicated=True,layout='unique-token-owner / compact-expert-major',
            branches=flat.numel(),source_tokens=tokens.shape[0],input_capacity=self.capacity,
            unique_capacity=self.p*self.c,epoch=self.epoch,return_dtype=str(tokens.dtype),
            preweighted=True,expert_backend='peer_tma_swiglu',owner_reduction='slot_order_fp32_then_bf16',
            fixed_a2a=False,ep_size=self.p)


_WORKSPACES: dict[tuple,DeduplicatedPeerSwiGLU] = {}


def deduplicated_peer_forward(tokens: torch.Tensor, ids: torch.Tensor, weights: torch.Tensor,
                              w13: torch.Tensor, w2: torch.Tensor, group: dist.ProcessGroup, *,
                              source_rows: list[int], stages: Stages | None = None,
                              validate: bool = True) -> tuple[torch.Tensor,dict]:
    """Dynamic routes, shared capacity-bucket workspaces; no cached route values."""
    p,rank = dist.get_world_size(group),dist.get_rank(group)
    if len(source_rows)!=p or any(n<0 for n in source_rows) or source_rows[rank]!=tokens.shape[0]:
        raise ValueError(f'source_rows={source_rows} must match EP={p} and local N={tokens.shape[0]}')
    limit = triton.next_power_of_2(max(1,max(source_rows)))
    key = (group,tokens.device,tokens.shape[1],w13.shape[0],ids.shape[1],limit)
    workspace = _WORKSPACES.get(key)
    if workspace is None:
        workspace = DeduplicatedPeerSwiGLU(group,tokens.shape[1],w13.shape[0],ids.shape[1],
                                         [limit]*p,tokens.device)
        _WORKSPACES[key] = workspace
    return workspace.forward(tokens,ids,weights,w13,w2,stages=stages,validate=validate)


def clear_deduplicated_peer_workspaces() -> None:
    """Drain all submitted GPU work before releasing peer mappings/groups."""
    for workspace in _WORKSPACES.values():
        torch.cuda.synchronize(workspace.device)
    _WORKSPACES.clear()
