"""Readable PyTorch SwiGLU compute, usable without Triton on CPU or CUDA."""
import torch
import torch.nn.functional as F


def compute_local_experts_torch(
    tokens: torch.Tensor, local_ids: torch.Tensor, w13: torch.Tensor, w2: torch.Tensor,
) -> torch.Tensor:
    """Contiguous branch rows [R,H] -> FP32 [R,H], preserving row order.

    IDs [R] are local, weights [L,2F,H]/[L,H,F] match input dtype/device.
    Gate/up, SiLU and multiplication round in model dtype; down accumulates
    FP32. Python expert selection is a readable compute path, not a benchmark
    substitute for the grouped CUDA implementation.
    """
    result = torch.empty(tokens.shape, dtype=torch.float32, device=tokens.device)
    for expert in range(w13.shape[0]):
        rows = torch.where(local_ids == expert)[0]
        if rows.numel():
            gate, up = F.linear(tokens.index_select(0, rows), w13[expert]).chunk(2, -1)
            activated = F.silu(gate) * up
            result.index_copy_(0, rows, F.linear(activated.float(), w2[expert].float()))
    return result
