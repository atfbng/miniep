"""Default EP chain: unique token/owner NCCL A2A, local expansion and reduction.

The branch-based implementation in model/moe.py remains an independent baseline.
This module has no peer/TMA dependency; default CUDA compute reuses the existing
grouped GEMM, and the explicit PyTorch compute backend also supports CPU tests.
"""
import torch
import torch.distributed as dist

from mini_ep.distributed.all_to_all import exchange_splits, variable_split_all_to_all
from mini_ep.distributed.dedup import (
    pack_token_owners, expand_owner_branches, reduce_owner_branches, combine_owner_partials,
)
from mini_ep.distributed.topology import ExpertParallelTopology
from mini_ep.model.contracts import validate_inputs
from mini_ep.profiler.stages import Stages


def ep_forward(
    tokens: torch.Tensor, expert_ids: torch.Tensor, routing_weights: torch.Tensor,
    gate_up_weights: torch.Tensor, down_weights: torch.Tensor, group: dist.ProcessGroup,
    *, stages: Stages | None = None, validate: bool = True,
    expert_backend: str = "grouped", return_dtype: torch.dtype | None = None,
) -> tuple[torch.Tensor, dict]:
    """Unexpanded [N,H]/[N,K] -> original [N,H], FP32/BF16, CPU or CUDA.

    Local weights [L,2F,H]/[L,H,F] match activation dtype/device. The caller owns
    the EP group; EP ranks determine expert ownership, not global or CUDA ranks.
    Each unique vector [U,H] travels with IDs [U,K] int64 (-1 for other owners)
    and weights [U,K] FP32. Source-major received rows expand locally to branches.

    Every rank, including empty sources, enters exactly: count exchange, input
    A2A, ID A2A, weight A2A, owner-partial return A2A. Splits are P unique-row
    counts (not branch counts); return reverses send/recv. Weighted branches
    first round to return_dtype, then model dtype before ordered FP32 owner
    reduction; owner partials travel in model dtype to preserve the original
    rounding boundary. Final FP32 merge is in ascending owner rank order.

    NCCL/CUDA is the production transport. PyTorch compute plus Gloo/CPU is
    only a semantic test path, never evidence for GPU performance or overlap.
    Variable unique/nonzero sizes and split lists entail Host synchronization.
    """
    if tokens.dtype not in (torch.float32, torch.bfloat16):
        raise TypeError(f"only FP32/BF16 model activations supported, got {tokens.dtype}")
    topology = ExpertParallelTopology(
        gate_up_weights.shape[0] * dist.get_world_size(group),
        dist.get_world_size(group), dist.get_rank(group),
    )
    if validate:
        validate_inputs(tokens, expert_ids, routing_weights, gate_up_weights, down_weights, topology)
    requested_dtype = return_dtype
    return_dtype = tokens.dtype if return_dtype is None else return_dtype
    if return_dtype not in (torch.float32, torch.bfloat16, torch.float16):
        raise ValueError(f"return transport must be FP32/BF16/FP16, got {return_dtype}")
    if expert_backend not in ("grouped", "loop", "torch"):
        raise ValueError(f"unknown expert backend {expert_backend!r}")
    stages = stages or Stages()
    with stages.stage("DISPATCH"):
        packed = pack_token_owners(tokens, expert_ids, routing_weights, topology)
    with stages.stage("A2A_FORWARD"):
        send, recv = exchange_splits(packed.send_splits, group)
        received = variable_split_all_to_all(packed.packed_tokens, send, recv, group)
        ids = variable_split_all_to_all(packed.packed_expert_ids, send, recv, group)
        weights = variable_split_all_to_all(packed.packed_routing_weights, send, recv, group)
    with stages.stage("EXPERT"):
        expanded, branch_ids, branch_weights, lookup = expand_owner_branches(received, ids, weights)
        local_ids = topology.local_expert_id(branch_ids)
        if expert_backend == "grouped":
            from mini_ep.model.expert import compute_grouped_local_experts

            branches = compute_grouped_local_experts(
                expanded, local_ids, gate_up_weights, down_weights,
                branch_weights=branch_weights, output_dtype=return_dtype,
            )
        else:
            if expert_backend == "torch":
                from mini_ep.model.expert_torch import compute_local_experts_torch as compute
            else:
                from mini_ep.model.expert import compute_local_experts_loop as compute
            branches = (compute(expanded, local_ids, gate_up_weights, down_weights)
                        * branch_weights[:, None]).to(return_dtype)
        owner_partials = reduce_owner_branches(branches, lookup, model_dtype=tokens.dtype)
    with stages.stage("A2A_RETURN"):
        returned = variable_split_all_to_all(owner_partials, recv, send, group)
    with stages.stage("COMBINE"):
        result = combine_owner_partials(returned, packed.restore_index)
    return result, dict(
        transport="nccl", deduplicated=True, layout="unique-token-owner",
        model_dtype=str(tokens.dtype), return_dtype=str(branches.dtype),
        return_buffer_dtype=str(returned.dtype),
        return_dtype_requested="auto" if requested_dtype is None else str(requested_dtype),
        preweighted=True, fuse_return_weight=expert_backend == "grouped",
        owner_reduction="destination_fp32", send_splits=send, recv_splits=recv,
        send_rows=packed.packed_tokens.shape[0], recv_rows=received.shape[0],
        source_tokens=tokens.shape[0], branches=expert_ids.numel(),
        received_branches=expanded.shape[0], expert_backend=expert_backend,
        input_send_bytes=packed.packed_tokens.numel() * tokens.element_size(),
        return_send_bytes=owner_partials.numel() * owner_partials.element_size(),
        weight_send_bytes=packed.packed_routing_weights.numel() * 4,
        id_send_bytes=packed.packed_expert_ids.numel() * 8,
        fixed_pack_backend=None, fixed_rows_per_rank=None,
        send_padding_rows=0, recv_padding_rows=0,
    )
