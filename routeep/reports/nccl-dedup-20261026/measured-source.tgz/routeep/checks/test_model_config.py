"""Model-family selection and the shared/routed BF16 rounding boundary."""

import json
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from mini_ep.integration.config import model_metadata, engine_options
from validation.model_info import expected_layers, validated_model_shape


class ModelConfigTests(unittest.TestCase):
    @patch("mini_ep.integration.config.model_metadata", return_value={"model_family": "qwen3_5_moe", "num_hidden_layers": 40})
    def test_consumer_gpu_topology_keeps_real_ep(self, metadata):
        options = engine_options("unused", dp_size=2, external=True, tp_size=1,
                                 all2all_backend="allgather_reducescatter")
        self.assertEqual(options["tensor_parallel_size"], 1)
        self.assertEqual(options["data_parallel_size"], 2)
        self.assertTrue(options["enable_expert_parallel"])
        self.assertEqual(options["dtype"], "bfloat16")
        self.assertEqual(options["distributed_executor_backend"], "external_launcher")
        self.assertEqual(options["all2all_backend"], "allgather_reducescatter")
        default = engine_options("unused", dp_size=2, external=True)
        self.assertEqual(default["tensor_parallel_size"], 2)
        self.assertEqual(default["all2all_backend"], "deepep_high_throughput")

    def test_consumer_gpu_rejects_unsupported_layouts(self):
        for kwargs in (dict(tp_size=1), dict(tp_size=3),
                       dict(dp_size=2, tp_size=1),
                       dict(all2all_backend="allgather_reducescatter"),
                       dict(all2all_backend="unknown")):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                engine_options("unused", **kwargs)

    def test_validated_model_shapes(self):
        cases = (
            ("qwen3_moe", 48, 128, 768, None),
            ("qwen3_5_moe", 40, 256, 512, 512),
        )
        for family, layers, experts, intermediate, shared in cases:
            with self.subTest(family=family), tempfile.TemporaryDirectory() as name:
                text = dict(
                    num_hidden_layers=layers,
                    hidden_size=2048,
                    num_experts=experts,
                    num_experts_per_tok=8,
                    moe_intermediate_size=intermediate,
                    dtype="bfloat16",
                )
                if shared is not None:
                    text["shared_expert_intermediate_size"] = shared
                config = (
                    dict(model_type=family, text_config=text)
                    if shared is not None
                    else dict(model_type=family, **text)
                )
                path = Path(name) / "config.json"
                path.write_text(json.dumps(config))
                self.assertEqual(validated_model_shape(name)["num_hidden_layers"], layers)
                (config["text_config"] if shared is not None else config)[
                    "num_experts"
                ] += 1
                path.write_text(json.dumps(config))
                with self.assertRaises(ValueError):
                    validated_model_shape(name)

    def test_nested_text_config_and_coverage(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            (root / "config.json").write_text(
                json.dumps(
                    dict(
                        model_type="qwen3_5_moe", text_config=dict(num_hidden_layers=40)
                    )
                )
            )
            metadata = model_metadata(name)
            self.assertEqual(metadata["num_hidden_layers"], 40)
            (root / "environment.json").write_text(json.dumps(metadata))
            self.assertEqual(expected_layers(root), 40)
            (root / "environment.json").write_text(
                json.dumps(dict(model_family="qwen3_5_moe"))
            )
            with self.assertRaises(ValueError):
                expected_layers(root)


if __name__ == "__main__":
    unittest.main()
