"""Communication selection is independent of always-on deduplication."""
import builtins
import sys
import types
import unittest
from unittest.mock import patch
from mini_ep.integration.transport import get_transport, get_peer_forward


class TransportTests(unittest.TestCase):
    def test_portable_default(self):
        with patch.dict('os.environ', {}, clear=True):
            self.assertEqual(get_transport(), 'nccl')

    def test_explicit_transport_and_legacy_alias(self):
        for name, canonical in (('nccl','nccl'), ('peer','peer'), ('peer_dedup','peer')):
            with self.subTest(name=name), patch.dict('os.environ', {'MINIEP_TRANSPORT': name}):
                self.assertEqual(get_transport(), canonical)

    def test_invalid_selection(self):
        with patch.dict('os.environ', {'MINIEP_TRANSPORT': 'auto'}):
            with self.assertRaisesRegex(ValueError, 'auto'):get_transport()
        with self.assertRaisesRegex(ValueError, 'invalid'):get_peer_forward('invalid')

    def test_nccl_has_no_peer_import(self):
        with patch.object(builtins, '__import__', side_effect=ImportError('no peer support')):
            self.assertIsNone(get_peer_forward('nccl'))

    def test_peer_always_deduplicates(self):
        selected = types.ModuleType('mini_ep.distributed.peer_dedup')
        sentinel = object();selected.deduplicated_peer_forward = sentinel
        with patch.dict(sys.modules, {selected.__name__: selected}):
            self.assertIs(get_peer_forward('peer'), sentinel)
            self.assertIs(get_peer_forward('peer_dedup'), sentinel)


if __name__ == '__main__':unittest.main()
