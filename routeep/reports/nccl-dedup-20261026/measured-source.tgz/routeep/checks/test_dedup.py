"""CPU layout/precision tests independent of transport and optional GPU modules."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import unittest
from unittest.mock import patch
import torch
from mini_ep.distributed.dedup import (
    pack_token_owners, expand_owner_branches, reduce_owner_branches, combine_owner_partials,
)
from mini_ep.distributed.dispatch import pack_by_destination_rank
from mini_ep.distributed.topology import ExpertParallelTopology
from reference.dedup import pack_token_owners_reference
from reference.dispatch import combine_reference


class DedupTests(unittest.TestCase):
    def test_user_example_and_logical_payload(self):
        x = torch.tensor([[1., 2.]], dtype=torch.bfloat16)
        ids = torch.tensor([[0, 1, 2, 3, 128, 129, 130, 131]])
        weights = torch.full((1, 8), 1/8)
        topology = ExpertParallelTopology(256, 2, 0)
        packed = pack_token_owners(x, ids, weights, topology)
        self.assertEqual(packed.send_splits.tolist(), [1, 1])
        self.assertEqual(packed.packed_tokens.tolist(), [[1., 2.], [1., 2.]])
        self.assertEqual(packed.packed_expert_ids[1].tolist(), [-1]*4 + [128, 129, 130, 131])
        self.assertEqual(packed.restore_index.tolist(), [[0], [1]])
        self.assertEqual(pack_by_destination_rank(x, ids, weights, topology).send_splits.tolist(), [4, 4])
        self.assertEqual(2 * 2048 * 2, 8192)  # One remote input + one remote owner sum.

    def test_independent_pack_and_branch_expansion(self):
        torch.manual_seed(926)
        for dtype in (torch.float32, torch.bfloat16):
            for p in (1, 2, 4):
                topo = ExpertParallelTopology(8, p, 0)
                for n in (0, 1, 9):
                    for k in (1, 2, 8):
                        for skew in (False, True):
                            x = torch.randn(n, 14).to(dtype)[:, ::2]
                            ids = torch.randint(8, (n, 2*k))[:, ::2]
                            if skew: ids.zero_()
                            weights = torch.rand(n, 2*k)[:, ::2]
                            actual = pack_token_owners(x, ids, weights, topo)
                            expected = pack_token_owners_reference(x, ids, weights, topo)
                            for key in actual.__dataclass_fields__:
                                a, b = getattr(actual, key), getattr(expected, key)
                                torch.testing.assert_close(a, b, rtol=0, atol=0)
                                self.assertEqual((a.dtype, a.device), (b.dtype, b.device))
                                self.assertTrue(a.is_contiguous())
                            branch = pack_by_destination_rank(x, ids, weights, topo)
                            expanded, eids, eweights, lookup = expand_owner_branches(
                                actual.packed_tokens, actual.packed_expert_ids, actual.packed_routing_weights)
                            for a, b in ((expanded, branch.packed_tokens), (eids, branch.packed_expert_ids), (eweights, branch.packed_routing_weights)):
                                torch.testing.assert_close(a, b, atol=0, rtol=0)
                            self.assertEqual(int((lookup >= 0).sum()), n*k)

    def test_rounding_and_order_match_original_combine(self):
        torch.manual_seed(27)
        for dtype in (torch.float32, torch.bfloat16):
            for rd in (torch.float32, torch.bfloat16, torch.float16):
                for p in (1, 2, 4):
                    n, k, h = 9, 8, 7
                    ids = torch.randint(8, (n, k));weights = torch.rand(n, k)
                    topo = ExpertParallelTopology(8, p, 0)
                    packed = pack_token_owners(torch.zeros(n,h,dtype=dtype), ids, weights, topo)
                    _, _, _, lookup = expand_owner_branches(packed.packed_tokens, packed.packed_expert_ids, packed.packed_routing_weights)
                    original = pack_by_destination_rank(torch.zeros(n,h,dtype=dtype), ids, weights, topo)
                    # Synthetic outputs already include routing weights; the reduction
                    # must neither multiply again nor alter branch/owner boundaries.
                    outputs = (torch.randn(n*k,h)*300).to(rd)
                    actual = combine_owner_partials(reduce_owner_branches(outputs, lookup, model_dtype=dtype), packed.restore_index)
                    expected = combine_reference(outputs, original.restore_index, ids, topo, model_dtype=dtype)
                    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
        trap = torch.tensor([[256.], [1.], [-256.], [1.]], dtype=torch.bfloat16)
        owner = reduce_owner_branches(trap, torch.tensor([[0,1,2,3]]), model_dtype=torch.bfloat16)
        self.assertEqual(owner.item(), 2.)
        self.assertEqual(reduce_owner_branches(torch.tensor([[1.],[2.],[3.],[4.]]), torch.tensor([[0,1,2,3]]), model_dtype=torch.bfloat16).item(), 10.)

    def test_missing_owners_and_empty(self):
        for n in (0, 3):
            actual = combine_owner_partials(torch.empty(0, 2, dtype=torch.bfloat16), torch.full((4,n), -1))
            self.assertEqual(actual.shape, (n, 2))
            self.assertEqual(actual.dtype, torch.bfloat16)
            self.assertEqual(actual.count_nonzero().item(), 0)
        for k in (1,8):
            reduced = reduce_owner_branches(torch.empty(0,2), torch.empty(0,k,dtype=torch.long), model_dtype=torch.float32)
            self.assertEqual(reduced.shape, (0,2))


if __name__ == '__main__':
    unittest.main()
